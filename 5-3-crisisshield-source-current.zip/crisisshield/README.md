# CrisisShield

Electronics inspection and shop workdesk.

## Run

npm ci
npm run dev

## Build

npm run build

The deployed root index.html is a self-contained production bundle. The source archive contains the editable React/Vite project.

## Data and limits

No login or backend. My shop records stay in the current browser profile. Demo records are fictional and separate. Export a backup before clearing browser data. Photos are evidence for manual review, not an originality or counterfeit verdict. Prices are manually recorded, not a live market feed.
