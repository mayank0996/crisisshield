# CrisisShield

Electronics inspection and shop workdesk.

## Run

npm ci
npm run dev

## Build

npm run build

The deployed root index.html is a self-contained production bundle. The source archive contains the editable React/Vite project.

## Data and limits

No login or backend. My shop records stay in the current browser profile. Demo records are fictional and separate. Export a backup before clearing browser data. Photos are evidence for manual review, not an originality or counterfeit verdict. Prices are manually recorded, not a live market feed.

## Student sample-product page

On Check, use Open sample product for a fictional earbuds demonstration. Load matching details to pass the local rule, or try a mismatched ID. The editable fields are compared only with an invented reference stored in the page. No manufacturer verification or real-device certification takes place. This page uses session state only and never writes to shop inventory or inspection history.
