import { SampleProduct } from './views/SampleProduct';
import React, { useState } from 'react';
import { Closing, FileCard, Header, NavLink, Route, Routes } from './ui';
import { DB, richDemoSeed, useDeskDB } from './lib/store';
import { Home } from './views/Home';
import { Check } from './views/Check';
import { Stock } from './views/Stock';
import { Sales } from './views/Sales';
import { Sellers } from './views/Sellers';
import { Motion } from './lib/Motion';
import { Wallet } from './views/Wallet';
import { Insights, Customers } from './views/Insights';
import { Settings } from './views/Settings';

export function App() {
    const [workspace, setWorkspace] = useState<'demo'|'shop'>('demo');
    const real = useDeskDB();
    const [practice,setPractice] = useState<DB>(richDemoSeed);
    const demo = {db:practice,ready:true,saved:{ok:true,ready:true,message:'Session-only demo workspace. My shop records are separate.'},update:(fn:(d:DB)=>DB)=>setPractice(fn),replace:setPractice};
    return <Desk key={workspace} workspace={workspace} onWorkspace={setWorkspace} state={workspace==='demo'?demo:real} />;
}
function Desk({workspace,onWorkspace,state}: {workspace:'demo'|'shop';onWorkspace:(s:'demo'|'shop')=>void;state:ReturnType<typeof useDeskDB>}) {
    const { db, ready, saved, update, replace } = state;

    return <FileCard>
        <Motion />
        <div className="desk-masthead">
            <Header title="CrisisShield" />
            <span className="desk-status"><i />{db.shopName || 'My shop'}</span>
        </div>
        <div className="workspace-bar"><div><button aria-pressed={workspace==='demo'} onClick={()=>onWorkspace('demo')}>Demo workspace</button><button aria-pressed={workspace==='shop'} onClick={()=>onWorkspace('shop')}>My shop</button></div><span>{workspace==='demo'?'Fictional records · session only':'Your separate records'}</span></div>
        <nav className="file-nav app-nav" aria-label="Desk sections">
            <NavLink to="/" end><span className="nav-number">01</span>Overview</NavLink>
            <NavLink to="/check"><span className="nav-number">02</span>Check</NavLink>
            <NavLink to="/stock"><span className="nav-number">03</span>Stock</NavLink>
            <NavLink to="/sales"><span className="nav-number">04</span>Sales</NavLink>
            <NavLink to="/sellers"><span className="nav-number">05</span>Sellers</NavLink>
            <NavLink to="/insights"><span className="nav-number">06</span>Pricing</NavLink>
            <NavLink to="/customers"><span className="nav-number">07</span>Customers</NavLink>
            <NavLink to="/wallet"><span className="nav-number">08</span>Wallet</NavLink>
            <NavLink to="/settings"><span className="nav-number">09</span>Settings</NavLink>
        </nav>
        {!ready && <p className="loading-note">Loading your desk…</p>}
        {ready && <div className="route-stage"><Routes>
            <Route path="/" element={<Home db={db} />} />
            <Route path="/check" element={<Check db={db} saved={saved} update={update} />} />
            <Route path="/sample-product" element={<SampleProduct />} />
            <Route path="/stock" element={<Stock db={db} saved={saved} update={update} />} />
            <Route path="/sales" element={<Sales db={db} update={update} />} />
            <Route path="/sellers" element={<Sellers db={db} update={update} />} />
            <Route path="/settings" element={<Settings isDemo={workspace==='demo'} db={db} saved={saved} replace={replace} update={update} />} />
            <Route path="/wallet" element={<Wallet db={db} update={update} />} />
            <Route path="/insights" element={<Insights db={db} update={update} />} />
            <Route path="/customers" element={<Customers db={db} />} />
        </Routes></div>}
        <Closing>{workspace==='demo'?'Practice freely. My shop records stay separate.':'Device-local records. Keep a backup in Settings.'}</Closing>
    </FileCard>;
}
