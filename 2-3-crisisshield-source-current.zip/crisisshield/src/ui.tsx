import React,{createContext,useContext,useEffect,useState} from 'react';
const RouteContext=createContext('/');
function readRoute(){return location.hash.slice(1)||'/';}
export function FileRouter({children}:any){const [route,setRoute]=useState(readRoute);useEffect(()=>{const fn=()=>{setRoute(readRoute());window.scrollTo(0,0)};addEventListener('hashchange',fn);return()=>removeEventListener('hashchange',fn)},[]);return <RouteContext.Provider value={route}>{children}</RouteContext.Provider>}
export function Routes({children}:any){const route=useContext(RouteContext);return React.Children.toArray(children).find((c:any)=>c.props.path===route)||null;}
export function Route({element}:any){return element;}
export function Link({to,children,...p}:any){return <a href={'#'+to} {...p}>{children}</a>}
export function NavLink({to,end,children,...p}:any){const route=useContext(RouteContext);return <Link to={to} aria-current={route===to?'page':undefined} {...p}>{children}</Link>}
export function FileCard({children}:any){return <main className="file-card">{children}</main>}
export function Header({title}:any){return <header className="file-header"><h1 className="file-title">{title}</h1></header>}
export function Closing({children}:any){return <footer className="file-closing">{children}</footer>}
export function Group({label,heading,children}:any){return <section className="file-group" aria-label={label}>{label&&<div className="file-group-head">{heading?<h2 className="file-group-heading">{label}</h2>:<h3 className="file-group-label">{label}</h3>}</div>}{children}</section>}
export function Paragraph({children}:any){return <p className="file-paragraph">{children}</p>}
export function Caption({children}:any){return <p className="file-caption">{children}</p>}
export function FileButton({children,variant='primary',compact,...p}:any){return <button type="button" className={'file-button '+variant+(compact?' is-compact':'')} {...p}>{children}</button>}
export function ButtonLink({children,variant,compact,href,...p}:any){return <a href={href} target="_blank" rel="noopener noreferrer" className={'file-button '+(variant||'primary')} {...p}>{children}</a>}
export function TextLink({children,...p}:any){return <a target="_blank" rel="noopener noreferrer" {...p}>{children}</a>}
export function Callout({title,tone,children}:any){return <aside className={'file-callout '+(tone||'')}><strong>{title}</strong><div>{children}</div></aside>}
export function Bullets({items}:any){return <ul className="file-bullets">{items.map((s:any,i:number)=><li key={i}>{s}</li>)}</ul>}
export function ChoiceRow({label,options,value,onChange}:any){return <fieldset className="file-choice"><legend>{label}</legend><div>{options.map((o:any)=><FileButton key={o.value} variant="secondary" aria-pressed={value===o.value} onClick={()=>onChange(o.value)}>{o.label}</FileButton>)}</div></fieldset>}
export function Rows({children}:any){return <div className="file-rows">{children}</div>}
export function Row({name,detail,value,number}:any){return <div className="file-row">{number&&<span>{number}</span>}<div><strong>{name}</strong>{detail&&<p>{detail}</p>}</div>{value!==undefined&&<b>{value}</b>}</div>}
export function useLocalState<T>(key:string,initial:T):[T,(v:T)=>void,any]{const storageKey='crisisshield.'+key;const [state,setState]=useState<T>(()=>{try{const s=localStorage.getItem(storageKey);return s?JSON.parse(s):initial}catch{return initial}});const [error,setError]=useState('');const save=(value:T)=>{setState(value);try{localStorage.setItem(storageKey,JSON.stringify(value));setError('')}catch{setError('Saving failed. Export a backup before leaving this page.')}};return [state,save,{ready:true,message:error||'Saved in this browser only.'}];}
