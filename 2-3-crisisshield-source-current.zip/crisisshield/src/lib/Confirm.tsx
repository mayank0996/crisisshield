import React, { useState } from 'react';
import { FileButton } from '../ui';

// Destructive actions require a second deliberate tap.
export function ConfirmButton({ label, confirmLabel, onConfirm, variant }: {
    label: string;
    confirmLabel?: string;
    onConfirm: () => void;
    variant?: 'primary' | 'secondary' | 'ghost';
}) {
    const [armed, setArmed] = useState(false);
    return <FileButton
        variant={armed ? 'primary' : (variant || 'ghost')}
        compact
        onClick={() => {
            if (armed) {
                setArmed(false);
                onConfirm();
            } else {
                setArmed(true);
                setTimeout(() => setArmed(false), 4000);
            }
        }}
    >{armed ? (confirmLabel || 'Tap again to confirm') : label}</FileButton>;
}
