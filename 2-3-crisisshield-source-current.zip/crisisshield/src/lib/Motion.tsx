import {useEffect} from 'react';

// Tactile UI feedback only. Does not change or delay any action.
export function Motion(){
 useEffect(()=>{
  const media=window.matchMedia('(prefers-reduced-motion: reduce)');
  const pulse=(target:EventTarget|null,x?:number,y?:number)=>{
   if(media.matches||!(target instanceof Element))return;
   const el=target.closest<HTMLElement>('button,a.action-tile,a.round-action,.app-nav a');
   if(!el||el.hasAttribute('disabled')||el.closest('[hidden]'))return;
   el.getAnimations().filter(a=>a.id==='tap-spring').forEach(a=>a.cancel());
   const animation=el.animate([{transform:'translateY(0) scale(1)'},{transform:'translateY(2px) scale(.945)',offset:.20},{transform:'translateY(-2px) scale(1.025)',offset:.62},{transform:'translateY(0) scale(1)'}],{duration:680,easing:'cubic-bezier(.22,.8,.25,1)'});animation.id='tap-spring';
   const rect=el.getBoundingClientRect();const wave=document.createElement('i');wave.className='tap-wave';wave.setAttribute('aria-hidden','true');wave.style.left=((x??rect.left+rect.width/2)-rect.left)+'px';wave.style.top=((y??rect.top+rect.height/2)-rect.top)+'px';el.appendChild(wave);
   const ripple=wave.animate([{transform:'translate(-50%,-50%) scale(0)',opacity:.45},{transform:'translate(-50%,-50%) scale('+Math.max(rect.width,rect.height)/8+')',opacity:0}],{duration:850,easing:'cubic-bezier(.1,.6,.3,1)'});ripple.id='tap-ripple';ripple.onfinish=()=>wave.remove();ripple.oncancel=()=>wave.remove();
  };
  const pointer=(e:PointerEvent)=>pulse(e.target,e.clientX,e.clientY);
  const key=(e:KeyboardEvent)=>{if((e.key==='Enter'||e.key===' ')&&!e.repeat)pulse(e.target);};
  document.addEventListener('pointerdown',pointer);document.addEventListener('keydown',key);
  return()=>{document.removeEventListener('pointerdown',pointer);document.removeEventListener('keydown',key);};
 },[]);
 return null;
}
