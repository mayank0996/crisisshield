export function inr(n: number): string {
    const v = Math.round((n + Number.EPSILON) * 100) / 100;
    return '₹' + v.toLocaleString('en-IN', { maximumFractionDigits: 2 });
}

export function num(n: number): string {
    return n.toLocaleString('en-IN');
}

export function dayStamp(iso: string): string {
    const d = new Date(iso);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

export function timeStamp(iso: string): string {
    const d = new Date(iso);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) + ', ' +
        d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
}

export function uid(): string {
    return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
}

export function todayKey(): string {
    return new Date().toISOString().slice(0, 10);
}
