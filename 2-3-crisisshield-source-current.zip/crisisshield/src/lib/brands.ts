// Official maker and government verification pages: strong supporting evidence.
// Only the manufacturer's own database can confirm a serial was issued, and only
// BIS can confirm a registration number - and even then, a valid serial does not
// by itself prove the physical item in hand matches it. Links verified 16 Nov 2026.

export type BrandCheck = {
    brand: string;
    label: string;
    url: string;
    hint: string;
};

export const BRAND_CHECKS: BrandCheck[] = [
    {
        brand: 'Apple',
        label: 'Check coverage on Apple',
        url: 'https://checkcoverage.apple.com/in/en',
        hint: 'Enter the serial number. Apple shows the model it belongs to and coverage. If the serial shows a different model, walk away.',
    },
    {
        brand: 'Xiaomi',
        label: 'Xiaomi product authentication',
        url: 'https://www.mi.com/global/verify',
        hint: 'Phones check by IMEI or serial; accessories by the 20-digit code under the scratch coating on the anti-counterfeit label.',
    },
    {
        brand: 'Samsung',
        label: 'Samsung My Products',
        url: 'https://www.samsung.com/in/mypage/myproducts/',
        hint: 'Register the device with its serial or IMEI (free Samsung account). An invalid or already-registered number is a warning sign.',
    },
    {
        brand: 'Dell',
        label: 'Dell support',
        url: 'https://www.dell.com/support',
        hint: 'Enter the service tag from the sticker. Dell shows the exact model, ship date and warranty.',
    },
    {
        brand: 'HP',
        label: 'HP warranty check',
        url: 'https://support.hp.com/in-en/check-warranty',
        hint: 'Enter the serial number. HP shows the product it belongs to and warranty status.',
    },
    {
        brand: 'Lenovo',
        label: 'Lenovo support',
        url: 'https://pcsupport.lenovo.com/',
        hint: 'Enter the serial number on the support page to see the model and warranty Lenovo has on record.',
    },
    {
        brand: 'Other',
        label: 'Search the maker\'s official site',
        url: 'https://www.google.com/search?q=warranty+check+serial+number',
        hint: 'Use only the brand\'s own website, never a link sent by the seller.',
    },
];

export const BIS_CHECKS = [
    {
        label: 'BIS Care app details',
        url: 'https://www.bis.gov.in/bis-apps/?lang=en',
        hint: 'The free official BIS Care app verifies the R-number printed with the standard mark on electronics under the Compulsory Registration Scheme (CRS).',
    },
    {
        label: 'BIS CRS portal',
        url: 'https://www.crsbis.in/BIS/about-crs.do',
        hint: 'The CRS portal lists registered manufacturers. Search the R-number (digits after "R-") and match the brand and model in the scope of registration.',
    },
];

export const MARKING_CHECKLIST = [
    'Brand logo spelling and printing look right (fakes often get fonts or spelling wrong)',
    'Model number on the device matches the box and the bill',
    'Serial number or IMEI is printed on the device itself, not only on the box',
    'For phones: *#06# shows an IMEI that matches the box sticker',
    'BIS standard mark with an R-number is printed on the device or adapter',
    'MRP label with price, month of manufacture and importer details is present',
    'Accessories and cable look sealed and finished, not loose or rough',
    'No screwdriver marks, dust inside ports, or worn charging port (signs of a used or refurbished unit sold as new)',
];
