import { useEffect, useRef, useState } from 'react';
import { useLocalState } from '../ui';
import { uid, todayKey } from './format';

export type Product = {
    id: string; name: string; sku: string; brand: string;
    cost: number; price: number; gst: number; stock: number; reorder: number;
    sellerId?: string; createdAt: string;
};

export type Sale = {
    id: string; productId: string; name: string; qty: number; unitPrice: number; unitCost?: number; gst: number;
    buyer?: string; customerKey?: string; mode: 'pickup' | 'delivery'; agent?: string;
    status: 'booked' | 'out' | 'delivered' | 'cancelled'; at: string;
};

export type Seller = {
    id: string; name: string; phone?: string; lots: number; issues: number; rating: number; note?: string;
};

export type PricePoint = { at: string; price: number };

export type CheckRecord = {
    id: string; at: string; brand: string; model: string; serial: string; rNumber: string;
    condition: string; markingsOk: number; markingsTotal: number; sellerName?: string; photoCount: number;
};

export type LedgerEntry={id:string;label:string;amount:number;due:string;kind:'expense'|'reminder';done:boolean};
export type Settings = { shopName: string; gstDefault: number; demoMode: boolean; ledger?:LedgerEntry[] };

export type DB = Settings & {
    products: Product[]; sales: Sale[]; sellers: Seller[];
    market: Record<string, PricePoint[]>; checks: CheckRecord[];
};

export type StorageState = { ok: boolean; ready: boolean; message: string };

export function emptyDB(): DB {
    return { shopName: 'My electronics shop', gstDefault: 18, demoMode: false, products: [], sales: [], sellers: [], market: {}, checks: [] };
}

const CHUNK_CHARS = 12000;
const MAX_SALES = 400;
const MAX_CHECKS = 20;

function chunkItems<T>(items: T[], parts: number): T[][] {
    const chunks: T[][] = [[]];
    let size = 2;
    for (const item of items) {
        const s = JSON.stringify(item).length + 1;
        if (size + s > CHUNK_CHARS && chunks.length < parts && chunks[chunks.length - 1].length > 0) {
            chunks.push([]);
            size = 2;
        }
        chunks[chunks.length - 1].push(item);
        size += s;
    }
    while (chunks.length < parts) chunks.push([]);
    return chunks.slice(0, parts);
}

export function dbBytes(db: DB): number {
    return JSON.stringify(db).length;
}

type Setter = (v: any) => void;

function setIfChanged(setter: Setter, value: any, last: React.MutableRefObject<string>) {
    const json = JSON.stringify(value);
    if (last.current === json) return;
    last.current = json;
    setter(value);
}

export function useDeskDB(namespace = 'desk.v1', seed = false): { db: DB; ready: boolean; saved: StorageState; update: (fn: (db: DB) => DB) => void; replace: (db: DB) => void } {
    const [settings, setSettings, svSettings] = useLocalState<Settings | null>(namespace + '.settings', null);
    const [p0, setP0, svP0] = useLocalState<Product[]>(namespace + '.products.0', []);
    const [p1, setP1, svP1] = useLocalState<Product[]>(namespace + '.products.1', []);
    const [p2, setP2, svP2] = useLocalState<Product[]>(namespace + '.products.2', []);
    const [p3, setP3, svP3] = useLocalState<Product[]>(namespace + '.products.3', []);
    const [s0, setS0, svS0] = useLocalState<Sale[]>(namespace + '.sales.0', []);
    const [s1, setS1, svS1] = useLocalState<Sale[]>(namespace + '.sales.1', []);
    const [s2, setS2, svS2] = useLocalState<Sale[]>(namespace + '.sales.2', []);
    const [s3, setS3, svS3] = useLocalState<Sale[]>(namespace + '.sales.3', []);
    const [sellers, setSellers, svSellers] = useLocalState<Seller[]>(namespace + '.sellers', []);
    const [market, setMarket, svMarket] = useLocalState<Record<string, PricePoint[]>>(namespace + '.market', {});
    const [c0, setC0, svC0] = useLocalState<CheckRecord[]>(namespace + '.checks.0', []);
    const [c1, setC1, svC1] = useLocalState<CheckRecord[]>(namespace + '.checks.1', []);

    const svs = [svSettings, svP0, svP1, svP2, svP3, svS0, svS1, svS2, svS3, svSellers, svMarket, svC0, svC1];
    const ready = svs.every(sv => sv.ready);

    const [db, setDb] = useState<DB | null>(null);
    const loadedRef = useRef(false);
    const lastRef = useRef('');

    useEffect(() => {
        if (!ready || loadedRef.current) return;
        loadedRef.current = true;
        const assembled: DB = {
            shopName: settings && settings.shopName ? settings.shopName : 'My electronics shop',
            gstDefault: settings && typeof settings.gstDefault === 'number' ? settings.gstDefault : 18,
            demoMode: !!(settings && settings.demoMode),
            ledger: settings?.ledger||[],
            products: [...p0, ...p1, ...p2, ...p3],
            sales: [...s0, ...s1, ...s2, ...s3],
            sellers: sellers || [],
            market: market || {},
            checks: [...c0, ...c1],
        };
        lastRef.current = seed && !settings ? '' : JSON.stringify(assembled);
        setDb(seed && !settings ? richDemoSeed() : assembled);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ready]);

    useEffect(() => {
        if (!ready || !db) return;
        const json = JSON.stringify(db);
        if (json === lastRef.current) return;
        lastRef.current = json;
        setSettings({ shopName: db.shopName, gstDefault: db.gstDefault, demoMode: db.demoMode,ledger:db.ledger });
        const pc = chunkItems(db.products, 4);
        setP0(pc[0]); setP1(pc[1]); setP2(pc[2]); setP3(pc[3]);
        const sc = chunkItems(db.sales.slice(0, MAX_SALES), 4);
        setS0(sc[0]); setS1(sc[1]); setS2(sc[2]); setS3(sc[3]);
        setSellers(db.sellers);
        setMarket(db.market);
        const cc = chunkItems(db.checks.slice(0, MAX_CHECKS), 2);
        setC0(cc[0]); setC1(cc[1]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [db, ready]);

    const update = (fn: (db: DB) => DB) => setDb(prev => (prev ? fn(prev) : prev));
    const replace = (next: DB) => setDb(next);

    const message = (svs.find(sv => sv.message) || {}).message || (ready ? 'Saved on this device.' : 'Loading your desk…');
    const saved: StorageState = { ok: ready, ready, message };

    return { db: db || emptyDB(), ready, saved, update, replace };
}

// ---- derived maths (the modelling layer) ----

export function soldQty(db: DB, productId: string, days: number): number {
    const from = Date.now() - days * 86400000;
    return db.sales.filter(s => s.status!=='cancelled' && s.productId === productId && new Date(s.at).getTime() >= from)
        .reduce((a, s) => a + s.qty, 0);
}

export type Pace = { label: string; tone: 'fast' | 'slow' | 'ok' | 'none'; daysCover: number | null };

export function stockPace(db: DB, p: Product): Pace {
    const s7 = soldQty(db, p.id, 7);
    const s14 = soldQty(db, p.id, 14);
    if (s7 > 0) {
        const cover = p.stock / (s7 / 7);
        if (cover < 7) return { label: 'Selling fast', tone: 'fast', daysCover: Math.round(cover) };
        return { label: 'Moving', tone: 'ok', daysCover: Math.round(cover) };
    }
    if (p.stock > 0 && s14 === 0) return { label: 'Slow moving', tone: 'slow', daysCover: null };
    return { label: 'No sales yet', tone: 'none', daysCover: null };
}

export function marketTrend(points: PricePoint[] | undefined): { delta: number | null; last: number | null } {
    if (!points || points.length === 0) return { delta: null, last: null };
    const last = points[points.length - 1].price;
    if (points.length < 2) return { delta: null, last };
    const prev = points[points.length - 2].price;
    if (prev <= 0) return { delta: null, last };
    return { delta: ((last - prev) / prev) * 100, last };
}

export function sellerBadge(s: Seller): { label: string; detail: string } {
    const rate = s.lots > 0 ? s.issues / s.lots : 1;
    if (s.lots >= 10 && s.rating >= 4 && rate < 0.05) {
        return { label: 'Meets shop rule', detail: `${s.lots} lots bought, ${s.issues} issues, your rating ${s.rating}/5. Shop rule: 10+ lots, under 5% problem lots, 4+ rating.` };
    }
    if (s.lots >= 3 && s.rating >= 3) {
        return { label: 'Building record', detail: `${s.lots} lots bought, ${s.issues} issues, your rating ${s.rating}/5. Needs 10+ lots, under 5% problem lots and 4+ rating to meet the shop rule.` };
    }
    return { label: 'New or unproven', detail: `${s.lots} lots bought, ${s.issues} issues, your rating ${s.rating}/5.` };
}

// GST on MRP-style (tax inclusive) prices. Components are rounded to paise once,
// here, with the remainder allocated so base + CGST + SGST always equals the total.
export function gstSplit(amountIncl: number, rate: number): { base: number; tax: number; cgst: number; sgst: number } {
    const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
    const base = r2(amountIncl / (1 + rate / 100));
    const tax = r2(amountIncl - base);
    const cgst = r2(tax / 2);
    const sgst = r2(tax - cgst);
    return { base, tax, cgst, sgst };
}

export function saleTotal(s: Sale): number {
    return s.status==='cancelled'?0:s.qty * s.unitPrice;
}

export function todaySales(db: DB): number {
    const key = todayKey();
    return db.sales.filter(s => s.at.slice(0, 10) === key).reduce((a, s) => a + saleTotal(s), 0);
}

export function weekRevenue(db: DB): { label: string; value: number }[] {
    const out: { label: string; value: number }[] = [];
    for (let i = 6; i >= 0; i--) {
        const d = new Date(Date.now() - i * 86400000);
        const key = d.toISOString().slice(0, 10);
        const value = db.sales.filter(s => s.at.slice(0, 10) === key).reduce((a, s) => a + saleTotal(s), 0);
        out.push({ label: d.toLocaleDateString('en-IN', { weekday: 'short' }), value });
    }
    return out;
}

export function demoSeed(): DB {
    const db = emptyDB();
    db.shopName = 'Demo electronics shop';
    const s1: Seller = { id: uid(), name: 'Sharma Traders', phone: '', lots: 14, issues: 0, rating: 5, note: 'Sealed boxes, GST bill every time.' };
    const s2: Seller = { id: uid(), name: 'City Mobiles Wholesale', phone: '', lots: 4, issues: 1, rating: 3, note: 'One lot had opened seals.' };
    db.sellers = [s1, s2];
    const mk = (name: string, sku: string, brand: string, cost: number, price: number, stock: number, reorder: number, sellerId: string): Product =>
        ({ id: uid(), name, sku, brand, cost, price, gst: 18, stock, reorder, sellerId, createdAt: new Date().toISOString() });
    const p1 = mk('Boat Airdopes 131', 'ADP-131', 'boAt', 799, 1299, 22, 8, s1.id);
    const p2 = mk('Mi 20W fast charger', 'CHG-MI20', 'Xiaomi', 349, 599, 5, 10, s1.id);
    const p3 = mk('Samsung 25W travel adapter', 'CHG-S25', 'Samsung', 899, 1499, 14, 6, s2.id);
    const p4 = mk('Portronics Type-C cable 1m', 'CBL-TC1', 'Portronics', 129, 249, 40, 15, s1.id);
    db.products = [p1, p2, p3, p4];
    const day = 86400000;
    db.sales = [
        { id: uid(), productId: p1.id, name: p1.name, qty: 2, unitPrice: p1.price, gst: 18, buyer: 'Walk-in', mode: 'pickup', status: 'delivered', at: new Date(Date.now() - 5 * day).toISOString() },
        { id: uid(), productId: p4.id, name: p4.name, qty: 5, unitPrice: p4.price, gst: 18, buyer: 'Walk-in', mode: 'pickup', status: 'delivered', at: new Date(Date.now() - 3 * day).toISOString() },
        { id: uid(), productId: p1.id, name: p1.name, qty: 1, unitPrice: p1.price, gst: 18, buyer: 'Rohan', mode: 'delivery', agent: 'Amit', status: 'out', at: new Date(Date.now() - 1 * day).toISOString() },
        { id: uid(), productId: p3.id, name: p3.name, qty: 1, unitPrice: p3.price, gst: 18, buyer: 'Meena', mode: 'delivery', agent: '', status: 'booked', at: new Date().toISOString() },
    ];
    db.market = { [p1.id]: [{ at: new Date(Date.now() - 7 * day).toISOString(), price: 1399 }, { at: new Date().toISOString(), price: 1299 }] };
    return db;
}

export function richDemoSeed(): DB {
    const d=demoSeed(); d.shopName='Circuit & Co.';
    const extra: [string,string,string,number,number,number][]=[['USB-C braided cable','CBL-BRD','Portronics',159,349,36],['Wireless mouse','MSE-WL','Logitech',499,799,18],['Neckband earphones','AUD-NB','boAt',699,1199,24],['20,000mAh power bank','PWR-20','Ambrane',999,1599,11],['Phone stand','STD-01','Generic',89,249,30],['Laptop sleeve 14 inch','SLV-14','Generic',349,699,22]];
    extra.forEach((p,i)=>d.products.push({id:'demo-p'+i,name:p[0],sku:p[1],brand:p[2],cost:p[3],price:p[4],stock:p[5],gst:18,reorder:6,sellerId:d.sellers[i%2].id,createdAt:new Date(Date.now()-60*86400000).toISOString()}));
    d.sales=[];
    const names=['Rohan','Meena','Ayesha','Kabir','Isha','Arjun','Neha','Dev'];
    for(let day=0;day<28;day++) {
        const picks=day<7?[0,2,4,7]:[0,3,5];
        picks.forEach((idx,j)=>{
            if(day%3===1&&j===2)return;
            const p=d.products[idx]; const person=(day+j)%names.length;
            d.sales.push({id:'ds-'+day+'-'+j,productId:p.id,name:p.name,qty:1+(day%3===0?1:0),unitPrice:p.price,unitCost:p.cost,gst:p.gst,buyer:names[person],customerKey:'C-10'+person,mode:day<2&&j===0?'delivery':'pickup',agent:day<2?'Amit':undefined,status:day<2&&j===0?(day===0?'booked':'out'):'delivered',at:new Date(Date.now()-day*86400000-j*3600000).toISOString()});
        });
    }
    d.ledger=[{id:'demo-rent',label:'Shop rent',amount:8000,due:new Date().toISOString().slice(0,10),kind:'expense',done:true},{id:'demo-due',label:'Review supplier bill',amount:0,due:new Date(Date.now()+3*86400000).toISOString().slice(0,10),kind:'reminder',done:false}];
    d.market={}; d.products.forEach((p,i)=>{d.market[p.id]=[{at:new Date(Date.now()-7*86400000).toISOString(),price:p.price+100},{at:new Date().toISOString(),price:p.price+(i%2===0?-50:50)}]});
    return d;
}
