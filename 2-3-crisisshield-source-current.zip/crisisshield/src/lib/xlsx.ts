// Minimal, dependency-free spreadsheet reader.
// Reads .xlsx by unpacking the ZIP with the browser's built-in DecompressionStream,
// and .csv with a small quoted-field parser. No code leaves the device.

async function inflate(data: Uint8Array): Promise<Uint8Array> {
    const DS = (window as any).DecompressionStream;
    if (!DS) throw new Error('no-decompression-stream');
    const stream = new Blob([data]).stream().pipeThrough(new DS('deflate-raw'));
    const buf = await new Response(stream).arrayBuffer();
    return new Uint8Array(buf);
}

function findEOCD(bytes: Uint8Array): number {
    for (let i = bytes.length - 22; i >= 0; i--) {
        if (bytes[i] === 0x50 && bytes[i + 1] === 0x4b && bytes[i + 2] === 0x05 && bytes[i + 3] === 0x06) return i;
    }
    throw new Error('Not a valid .xlsx file (no ZIP directory found).');
}

type ZipEntry = { name: string; method: number; size: number; offset: number };

function listEntries(bytes: Uint8Array): ZipEntry[] {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const eocd = findEOCD(bytes);
    const count = view.getUint16(eocd + 10, true);
    let pos = view.getUint32(eocd + 16, true);
    const out: ZipEntry[] = [];
    for (let i = 0; i < count; i++) {
        if (view.getUint32(pos, true) !== 0x02014b50) break;
        const method = view.getUint16(pos + 10, true);
        const size = view.getUint32(pos + 20, true);
        const offset = view.getUint32(pos + 42, true);
        const nameLen = view.getUint16(pos + 28, true);
        const name = new TextDecoder().decode(bytes.slice(pos + 46, pos + 46 + nameLen));
        out.push({ name, method, size, offset });
        pos += 46 + nameLen + view.getUint16(pos + 30, true) + view.getUint16(pos + 32, true);
    }
    return out;
}

async function readEntry(bytes: Uint8Array, e: ZipEntry): Promise<string> {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (view.getUint32(e.offset, true) !== 0x04034b50) throw new Error('Corrupt .xlsx (bad local header).');
    const nameLen = view.getUint16(e.offset + 26, true);
    const extraLen = view.getUint16(e.offset + 28, true);
    const start = e.offset + 30 + nameLen + extraLen;
    const compSize = view.getUint32(e.offset + 18, true);
    const raw = bytes.slice(start, start + compSize);
    let data: Uint8Array;
    if (e.method === 0) data = raw;
    else if (e.method === 8) data = await inflate(raw);
    else throw new Error('Unsupported compression in this .xlsx.');
    return new TextDecoder().decode(data);
}

function colIndex(cellRef: string): number {
    let n = 0;
    for (const ch of cellRef) {
        if (ch >= 'A' && ch <= 'Z') n = n * 26 + (ch.charCodeAt(0) - 64);
        else break;
    }
    return n - 1;
}

function textOf(el: Element | null): string {
    if (!el) return '';
    return el.textContent || '';
}

export async function parseXlsx(buf: ArrayBuffer): Promise<string[][]> {
    const bytes = new Uint8Array(buf);
    const entries = listEntries(bytes);
    const byName = (n: string) => entries.find(e => e.name === n);

    // Locate the first worksheet through the workbook rels, falling back to sheet1.
    let sheetPath = 'xl/worksheets/sheet1.xml';
    const wb = byName('xl/workbook.xml');
    const rels = byName('xl/_rels/workbook.xml.rels');
    if (wb && rels) {
        try {
            const wbDoc = new DOMParser().parseFromString(await readEntry(bytes, wb), 'application/xml');
            const firstSheet = wbDoc.getElementsByTagName('sheet')[0];
            const rid = firstSheet ? firstSheet.getAttribute('r:id') : null;
            if (rid) {
                const relDoc = new DOMParser().parseFromString(await readEntry(bytes, rels), 'application/xml');
                const relsEls = relDoc.getElementsByTagName('Relationship');
                for (let i = 0; i < relsEls.length; i++) {
                    if (relsEls[i].getAttribute('Id') === rid) {
                        const target = relsEls[i].getAttribute('Target') || '';
                        sheetPath = target.startsWith('/') ? target.slice(1) : 'xl/' + target.replace(/^\.\//, '');
                        break;
                    }
                }
            }
        } catch (e) { /* keep sheet1 fallback */ }
    }

    const sheetEntry = byName(sheetPath) || byName('xl/worksheets/sheet1.xml');
    if (!sheetEntry) throw new Error('No worksheet found in this .xlsx.');

    let shared: string[] = [];
    const ss = byName('xl/sharedStrings.xml');
    if (ss) {
        const ssDoc = new DOMParser().parseFromString(await readEntry(bytes, ss), 'application/xml');
        const si = ssDoc.getElementsByTagName('si');
        for (let i = 0; i < si.length; i++) {
            const ts = si[i].getElementsByTagName('t');
            let text = '';
            for (let j = 0; j < ts.length; j++) text += ts[j].textContent || '';
            shared.push(text);
        }
    }

    const sheetDoc = new DOMParser().parseFromString(await readEntry(bytes, sheetEntry), 'application/xml');
    const rows = sheetDoc.getElementsByTagName('row');
    const out: string[][] = [];
    for (let r = 0; r < rows.length; r++) {
        const cells = rows[r].getElementsByTagName('c');
        const line: string[] = [];
        for (let c = 0; c < cells.length; c++) {
            const cell = cells[c];
            const ref = cell.getAttribute('r') || '';
            const idx = ref ? colIndex(ref) : line.length;
            while (line.length < idx) line.push('');
            const t = cell.getAttribute('t');
            let value = '';
            if (t === 's') {
                const v = parseInt(textOf(cell.getElementsByTagName('v')[0]), 10);
                value = isNaN(v) ? '' : (shared[v] || '');
            } else if (t === 'inlineStr') {
                const is = cell.getElementsByTagName('is')[0];
                const ts = is ? is.getElementsByTagName('t') : ([] as any);
                let text = '';
                for (let j = 0; j < ts.length; j++) text += ts[j].textContent || '';
                value = text;
            } else {
                value = textOf(cell.getElementsByTagName('v')[0]);
            }
            line[idx] = value;
        }
        out.push(line);
    }
    return out.filter(line => line.some(v => String(v).trim() !== ''));
}

export function parseCsv(text: string): string[][] {
    const rows: string[][] = [];
    let row: string[] = [];
    let field = '';
    let inQuotes = false;
    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        if (inQuotes) {
            if (ch === '"') {
                if (text[i + 1] === '"') { field += '"'; i++; }
                else inQuotes = false;
            } else field += ch;
        } else if (ch === '"') {
            inQuotes = true;
        } else if (ch === ',') {
            row.push(field); field = '';
        } else if (ch === '\n' || ch === '\r') {
            if (ch === '\r' && text[i + 1] === '\n') i++;
            row.push(field); field = '';
            if (row.some(v => v.trim() !== '')) rows.push(row);
            row = [];
        } else field += ch;
    }
    row.push(field);
    if (row.some(v => v.trim() !== '')) rows.push(row);
    return rows;
}

export async function parseSpreadsheet(file: File): Promise<string[][]> {
    const name = file.name.toLowerCase();
    if (name.endsWith('.csv')) {
        return parseCsv(await file.text());
    }
    if (name.endsWith('.xlsx') || name.endsWith('.xlsm')) {
        return parseXlsx(await file.arrayBuffer());
    }
    throw new Error('Please pick a .xlsx or .csv file. From Excel or Google Sheets: File, then Save as or Download, then CSV.');
}

export function xlsxSupported(): boolean {
    return typeof window !== 'undefined' && !!(window as any).DecompressionStream;
}

// Guess which sheet column holds which field, from the header row.
const HEADER_MAP: Record<string, string[]> = {
    name: ['name', 'product', 'product name', 'item', 'item name', 'description', 'particulars'],
    sku: ['sku', 'code', 'item code', 'product code', 'model', 'model no', 'model no.', 'barcode'],
    qty: ['qty', 'quantity', 'stock', 'units', 'pcs', 'pieces', 'count'],
    cost: ['cost', 'cost price', 'purchase', 'purchase price', 'buy price', 'rate', 'landing price', 'dealer price'],
    price: ['price', 'sale price', 'selling price', 'sell price', 'mrp', 'retail', 'retail price'],
    gst: ['gst', 'gst%', 'gst %', 'tax', 'tax%', 'tax %', 'gst rate'],
    brand: ['brand', 'make', 'company', 'manufacturer'],
    seller: ['seller', 'dealer', 'supplier', 'vendor', 'distributor'],
};

export function guessMapping(header: string[]): Record<string, number> {
    const map: Record<string, number> = {};
    header.forEach((h, i) => {
        const clean = String(h || '').trim().toLowerCase();
        if (!clean) return;
        for (const field of Object.keys(HEADER_MAP)) {
            if (map[field] !== undefined) continue;
            if (HEADER_MAP[field].some(k => clean === k || clean.includes(k))) {
                map[field] = i;
                break;
            }
        }
    });
    return map;
}
