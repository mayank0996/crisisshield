import React, { useState } from 'react';
import { Callout, Caption, ChoiceRow, FileButton, Group, Paragraph, Row, Rows } from '../ui';
import { DB, gstSplit, saleTotal, weekRevenue } from '../lib/store';
import { inr, timeStamp, uid } from '../lib/format';

type Props = { db: DB; update: (fn: (db: DB) => DB) => void };

export function Sales({ db, update }: Props) {
    const [productId, setProductId] = useState('');
    const [qty, setQty] = useState('1');
    const [buyer, setBuyer] = useState('');
    const [customerKey,setCustomerKey]=useState('');
    const [saleDiscount,setSaleDiscount]=useState(0);
    const [mode, setMode] = useState<'pickup' | 'delivery'>('pickup');
    const [agent, setAgent] = useState('');
    const [msg, setMsg] = useState('');
    const [showAll,setShowAll]=useState(false);

    const product = db.products.find(p => p.id === productId);
    const q = Math.max(0, parseInt(qty || '0', 10) || 0);
    const unitPrice=product?Math.round(product.price*(1-saleDiscount/100)*100)/100:0;
    const total = product && q > 0 ? Math.round(q * unitPrice*100)/100 : 0;
    const split = product ? gstSplit(total, product.gst) : null;

    function record() {
        if (!product || q <= 0) return;
        if (q > product.stock) {
            setMsg(`Only ${product.stock} of ${product.name} in stock. Restock from the Stock tab first.`);
            return;
        }
        update(d => ({
            ...d,
            products: d.products.map(p => p.id === product.id ? { ...p, stock: p.stock - q } : p),
            sales: [{
                id: uid(), productId: product.id, name: product.name, qty: q, unitPrice, unitCost:product.cost,
                gst: product.gst, buyer: buyer.trim() || undefined, customerKey: customerKey.trim().toUpperCase() || undefined, mode,
                agent: mode === 'delivery' ? (agent.trim() || undefined) : undefined,
                status: mode === 'pickup' ? 'delivered' : 'booked', at: new Date().toISOString(),
            }, ...d.sales],
        }));
        setMsg(`Sale recorded: ${q} × ${product.name} for ${inr(total)}. Stock now ${product.stock - q}.`);
        setQty('1'); setBuyer(''); setCustomerKey(''); setAgent(''); setSaleDiscount(0);
    }

    function advance(id: string) {
        update(d => ({
            ...d,
            sales: d.sales.map(s => s.id === id ? { ...s, status: s.status === 'booked' ? 'out' : 'delivered' } : s),
        }));
    }

    const week = weekRevenue(db);
    const max = Math.max(1, ...week.map(w => w.value));
    const pending = db.sales.filter(s => s.mode === 'delivery' && s.status !== 'delivered' && s.status !== 'cancelled');

    return <>
        <Group label="Record a sale" heading>
            {db.products.length === 0 && <Caption>Add products on the Stock tab first.</Caption>}
            {db.products.length > 0 && (
                <>
                    <label className="field"><span>Product</span>
                        <select value={productId} onChange={e => { setProductId(e.target.value); setMsg(''); }}>
                            <option value="">Pick a product</option>
                            {db.products.map(p => <option key={p.id} value={p.id}>{p.name} ({p.stock} in stock)</option>)}
                        </select>
                    </label>
                    <div className="field-grid">
                        <label className="field"><span>Quantity</span>
                            <input inputMode="numeric" value={qty} onChange={e => setQty(e.target.value.replace(/[^0-9]/g, ''))} /></label>
                        <label className="field"><span>Buyer (optional)</span>
                            <input value={buyer} onChange={e => setBuyer(e.target.value)} placeholder="Name or walk-in" /></label>
                    </div>
                    <div className="field-grid"><label className="field"><span>Customer reference (optional)</span><input value={customerKey} onChange={e=>setCustomerKey(e.target.value)} placeholder="e.g. C-101, same on each visit" /></label><label className="field"><span>Discount for this sale %</span><input type="number" min="0" max="100" value={saleDiscount} onChange={e=>setSaleDiscount(Math.max(0,Math.min(100,Number(e.target.value)||0)))} /></label></div>
                    <ChoiceRow label="Handover" options={[{ value: 'pickup', label: 'Counter pickup' }, { value: 'delivery', label: 'Send with delivery agent' }]} value={mode} onChange={v => setMode(v as 'pickup' | 'delivery')} />
                    {mode === 'delivery' && (
                        <label className="field"><span>Delivery agent</span>
                            <input value={agent} onChange={e => setAgent(e.target.value)} placeholder="Agent's name" /></label>
                    )}
                    {product && q > 0 && split && (
                        <div className="bill-box">
                            <p><span>Sale total (MRP style, GST included)</span><strong>{inr(total)}</strong></p>
                            <p><span>Taxable value</span><strong>{inr(split.base)}</strong></p>
                            <p><span>CGST {product.gst / 2}%</span><strong>{inr(split.cgst)}</strong></p>
                            <p><span>SGST {product.gst / 2}%</span><strong>{inr(split.sgst)}</strong></p>
                        </div>
                    )}
                    <FileButton variant="primary" onClick={record} disabled={!product || q <= 0}>Record the sale</FileButton>
                    {msg && <Caption>{msg}</Caption>}
                    <Caption>Prices are treated as GST-inclusive (MRP style). The GST rate comes from each product; edit it there. This is a working calculator, not tax filing: confirm rates with your accountant.</Caption>
                </>
            )}
        </Group>

        {pending.length > 0 && (
            <Group label={`Deliveries in progress (${pending.length})`} heading>
                {pending.map(s => (
                    <div className="delivery-row" key={s.id}>
                        <div>
                            <p className="delivery-name">{s.qty} × {s.name}{s.buyer ? ' for ' + s.buyer : ''}</p>
                            <p className="delivery-meta">{s.agent ? 'Agent: ' + s.agent + ' · ' : ''}{timeStamp(s.at)} · {inr(saleTotal(s))}</p>
                        </div>
                        <FileButton variant={s.status === 'booked' ? 'secondary' : 'primary'} compact onClick={() => advance(s.id)}>
                            {s.status === 'booked' ? 'Mark out for delivery' : 'Mark delivered'}
                        </FileButton>
                    </div>
                ))}
            </Group>
        )}

        {db.sales.length > 0 && (
            <Group label="Last 7 days" heading>
                <div className="chart" role="img" aria-label="Revenue for the last 7 days">
                    {week.map((w, i) => (
                        <div className="chart-col" key={i}>
                            <div className={'chart-bar' + (i === week.length - 1 ? ' is-today' : '')} style={{ height: Math.max(3, Math.round((w.value / max) * 96)) + 'px' }} />
                            <span className="chart-label">{w.label}</span>
                            {w.value > 0 && <span className="chart-value">{inr(w.value)}</span>}
                        </div>
                    ))}
                </div>
                <Caption>Daily totals from the sales recorded here.</Caption>
            </Group>
        )}

        {db.sales.length > 0 && (
            <Group label={`Sales log (${db.sales.length})`} heading>
                <Rows>
                    {db.sales.slice(0, showAll?20:5).map(s => (
                        <Row key={s.id} name={`${s.qty} × ${s.name}`}
                            detail={`${timeStamp(s.at)}${s.buyer ? ' · ' + s.buyer : ''}${s.mode === 'delivery' ? ' · delivery ' + s.status : ''}`}
                            value={s.status==='cancelled'?'Cancelled':inr(saleTotal(s))} valueKnown />
                    ))}
                </Rows>
                {db.sales.length > 5 && <FileButton variant="secondary" compact onClick={()=>setShowAll(!showAll)}>{showAll?'Show fewer receipts':'Show more receipts'}</FileButton>}<Caption>Showing {Math.min(db.sales.length,showAll?20:5)} most recent receipts of {db.sales.length}.</Caption>
            </Group>
        )}
    </>;
}
