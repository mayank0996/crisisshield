import React, { useState } from 'react';
import { DB, soldQty, saleTotal } from '../lib/store';
import { inr, dayStamp } from '../lib/format';
import { FileButton, Link } from '../ui';

export function demandRows(db:DB) {
    return db.products.map(p=>{const recent=soldQty(db,p.id,7),previous=soldQty(db,p.id,14)-recent;return {p,recent,previous,total:soldQty(db,p.id,28),change:recent-previous};});
}
export function customerRows(db:DB) {
    const groups=new Map<string,{key:string;name:string;visits:number;spend:number;last:string;items:string[]}>();
    db.sales.forEach(s=>{if(s.status==='cancelled')return;if(!s.customerKey?.trim())return;const key=s.customerKey.trim().toUpperCase();const c=groups.get(key)||{key,name:s.buyer||key,visits:0,spend:0,last:s.at,items:[]};c.visits++;c.spend+=saleTotal(s);if(s.at>c.last){c.last=s.at;c.name=s.buyer||key;}c.items.push(s.name);groups.set(key,c);});
    return [...groups.values()].sort((a,b)=>b.spend-a.spend);
}
export function Insights({db,update}:{db:DB;update:(fn:(d:DB)=>DB)=>void}) {
    const [tab,setTab]=useState('slow'); const [id,setId]=useState(db.products[0]?.id||'');const [discount,setDiscount]=useState(5);const [floor,setFloor]=useState(10);const [msg,setMsg]=useState('');
    const rows=demandRows(db); const p=db.products.find(p=>p.id===id);const price=p?Math.round(p.price*(1-discount/100)*100)/100:0;const spread=p?price-p.cost:0;const spreadPct=price?spread/price*100:0;const safe=!!p&&price>0&&spreadPct>=floor;
    const show=tab==='slow'?[...rows].filter(r=>r.p.stock>0).sort((a,b)=>a.total-b.total):[...rows].filter(r=>r.change>0).sort((a,b)=>b.change-a.change);
    function apply(){if(!p||!safe)return; update(d=>({...d,products:d.products.map(x=>x.id===p.id?{...x,price}:x)}));setMsg(`Price updated: ${p.name} is now ${inr(price)}. New sales use this price; past sales stay unchanged.`);setDiscount(0);}
    return <>
      <div className="page-intro"><p className="eyebrow">Pricing desk</p><h2>Make the next<br/><span>move count.</span></h2><p>Signals from sales recorded here. Not a live market forecast.</p></div>
      <div className="segmented"><button aria-pressed={tab==='slow'} onClick={()=>setTab('slow')}>Least selling</button><button aria-pressed={tab==='rising'} onClick={()=>setTab('rising')}>Rising demand</button></div>
      <p className="mini-note">{tab==='slow'?'Units sold in the last 28 days, lowest first. New products may not have enough history.':'Last 7 days versus the preceding 7 days. Local demand only, not a prediction.'}</p>
      <div className="signal-list">{show.slice(0,6).map((r,i)=><button className={'signal-card '+(r.p.id===id?'chosen':'')} key={r.p.id} onClick={()=>{setId(r.p.id);setMsg('');}}><span className="signal-rank">0{i+1}</span><span><strong>{r.p.name}</strong><small>{r.p.stock} on hand · {tab==='slow'?r.total+' sold / 28d':r.previous+' → '+r.recent+' units / week'}</small></span><b>{tab==='slow'?r.total:'+'+r.change}</b></button>)}{!show.length&&<p>No matching sales signal yet. Record sales to build the picture.</p>}</div>
      <section className="pricing-lab"><div className="section-top"><span className="eyebrow">Offer studio</span><span>Manual approval</span></div><h3>Find room for an offer.</h3>
       <label className="field"><span>Product</span><select value={id} onChange={e=>{setId(e.target.value);setMsg('');}}>{db.products.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
       {p&&<><div className="scheme-buttons">{[{n:'Hold price',v:0},{n:'Gentle nudge',v:5},{n:'Move stock',v:10},{n:'Clear space',v:15}].map(s=><button key={s.v} aria-pressed={discount===s.v} onClick={()=>{setDiscount(s.v);setMsg('');}}>{s.n}<b>{s.v}%</b></button>)}</div>
       <label className="range-field"><span>Discount <b>{discount}%</b></span><input aria-label="Discount percent" type="range" min="0" max="40" step="1" value={discount} onChange={e=>{setDiscount(Number(e.target.value));setMsg('');}} /></label>
       <div className="offer-numbers"><div><small>Current price</small><strong>{inr(p.price)}</strong></div><span>→</span><div><small>Proposed price</small><strong>{inr(price)}</strong></div></div>
       <div className="price-detail"><span>Entered cost {inr(p.cost)}</span><span>Price-cost spread {inr(spread)} ({spreadPct.toFixed(1)}%)</span></div>
       <label className="field"><span>Minimum price-cost spread %</span><input type="number" min="0" max="100" value={floor} onChange={e=>setFloor(Math.min(100,Math.max(0,Number(e.target.value)||0)))} /></label>
       <p className="mini-note">Price-cost spread is not net profit. Tax basis, fees and operating costs are not modelled. No forecast of extra sales. Applying changes this product's price only, with no automatic repricing or customer messages.</p>
       {!safe&&<p role="status" className="price-warning">Below your minimum spread. Lower the discount or revise the floor.</p>}
       <FileButton variant="primary" disabled={!safe||discount===0} onClick={apply}>Apply proposed price</FileButton></>}
       {msg&&<p role="status" className="success-note">{msg}</p>}
      </section>
    </>;
}
export function Customers({db}:{db:DB}) {
    const [query,setQuery]=useState('');const [selected,setSelected]=useState('');const all=customerRows(db);const repeat=all.filter(c=>c.visits>1); const rows=all.filter(c=>(c.name+' '+c.key).toLowerCase().includes(query.toLowerCase()));
    return <><div className="page-intro"><p className="eyebrow">People behind the receipts</p><h2>Familiar faces.<br/><span>Better service.</span></h2></div><div className="customer-metrics"><div><strong>{all.length}</strong><span>Tracked customers</span></div><div><strong>{repeat.length}</strong><span>Repeat customers</span></div><div><strong>{all.length?Math.round(repeat.length/all.length*100):0}%</strong><span>With 2+ receipts</span></div></div>
      <p className="mini-note">Grouped only by the customer reference entered on each sale, not by name. Visits here mean receipts, not distinct trips. Walk-ins without a reference are excluded.</p>
      <label className="field"><span>Find a customer</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Name or customer reference" /></label>
      <div className="customer-list">{rows.map(c=><div className="customer-card" key={c.key}><button className="customer-head" aria-expanded={selected===c.key} onClick={()=>setSelected(selected===c.key?'':c.key)}><span className="avatar">{c.name.slice(0,1)}</span><span><strong>{c.name}</strong><small>{c.key} · {c.visits} receipts · Last {dayStamp(c.last)}</small></span><b>{inr(c.spend)}<small>{selected===c.key?'Close −':'Details +'}</small></b></button>{selected===c.key&&<div className="customer-expanded"><span className="eyebrow">Purchase history</span>{db.sales.filter(s=>s.status!=='cancelled'&&s.customerKey?.trim().toUpperCase()===c.key).slice(0,10).map(s=><p key={s.id}><span>{s.qty} × {s.name}<small>{dayStamp(s.at)}</small></span><strong>{inr(saleTotal(s))}</strong></p>)}<Link to="/sales" className="file-button is-compact">Record another sale</Link></div>}</div>)}{!rows.length&&<p>No customer records match. Add a customer reference when recording a sale.</p>}</div></>;
}
