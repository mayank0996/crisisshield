import React, { useRef, useState } from 'react';
import { Bullets, Callout, Caption, ChoiceRow, FileButton, Group, Paragraph, TextLink } from '../ui';
import { DB, dbBytes, richDemoSeed, emptyDB, StorageState } from '../lib/store';
import { BRAND_CHECKS, BIS_CHECKS } from '../lib/brands';
import { ConfirmButton } from '../lib/Confirm';

type Props = { isDemo?: boolean; db: DB; saved: StorageState; replace: (db: DB) => void; update: (fn: (db: DB) => DB) => void };

export function Settings({ db, saved, replace, update, isDemo }: Props) {
    const backupInput = useRef<HTMLInputElement | null>(null);
    const [msg, setMsg] = useState('');

    function exportBackup() {
        const blob = new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'shop-desk-backup.json';
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);
        setMsg('Backup downloaded. Keep it somewhere safe; it holds your stock, sales and seller records.');
    }

    async function importBackup(files: FileList | null) {
        const f = files && files[0];
        if (!f) return;
        try {
            const parsed = JSON.parse(await f.text());
            if (!parsed || !Array.isArray(parsed.products) || !Array.isArray(parsed.sales)) {
                setMsg('That file is not a backup from this app.');
                return;
            }
            replace({ ...emptyDB(), ...parsed });
            setMsg('Backup restored.');
        } catch (e) {
            setMsg('Could not read that file as a backup.');
        }
    }

    return <>
        <Group label="This desk" heading>
            <label className="field"><span>Shop name (shown at the top)</span>
                <input value={db.shopName} onChange={e => update(d => ({ ...d, shopName: e.target.value }))} /></label>
            <label className="field"><span>Default GST % for new products</span>
                <input inputMode="decimal" value={String(db.gstDefault)}
                    onChange={e => update(d => ({ ...d, gstDefault: parseFloat(e.target.value.replace(/[^0-9.]/g, '')) || 0 }))} /></label>
            <Caption>
                Phones and common accessories (chargers, earphones, cables, power banks, covers, tempered glass) are 18% GST
                under rate Notification 9/2025, unchanged at the October 2026 GST Council. Rates for other electronics differ,
                so keep the per-product rate editable and confirm with an accountant. Checked 16 Nov 2026.
            </Caption>
            <ChoiceRow label="Scripted exhibition demo mode"
                options={[{ value: 'off', label: 'Off (real checks)' }, { value: 'on', label: 'On (scripted two-device demo)' }]}
                value={db.demoMode ? 'on' : 'off'}
                onChange={v => update(d => ({ ...d, demoMode: v === 'on' }))} />
            <Caption>Demo mode replaces the Check tab with a clearly labelled scripted result for a two-device exhibition setup. It never claims a real detection.</Caption>
        </Group>

        <Group label="Your data" heading>
            <Paragraph>{isDemo?'This practice workspace lasts for this open session. Switching to My shop keeps the two workspaces separate.':'My shop is stored on this device in this browser, never synced to other devices. There is no login or account-level isolation. Anyone using this browser profile can access it. Keep a backup before clearing browser data or changing devices. Hosted-version records do not transfer automatically; use Export backup and Restore backup.'} {saved.message}</Paragraph>
            <Caption>Storage used now: about {Math.ceil(dbBytes(db) / 1024)} KB of a small device-local allowance. If a save fails, export a backup and clear old sales.</Caption>
            <input ref={backupInput} type="file" accept=".json,application/json" className="vh" onChange={e => { void importBackup(e.target.files); e.target.value = ''; }} />
            <div className="quick-actions">
                <FileButton variant="secondary" compact onClick={exportBackup}>Export backup</FileButton>
                <FileButton variant="secondary" compact onClick={() => backupInput.current && backupInput.current.click()}>Restore backup</FileButton>
            </div>
            <div className="quick-actions">
                {isDemo && <ConfirmButton label="Reset demo records" confirmLabel="Tap again: replaces current data" variant="secondary" onConfirm={() => { replace(richDemoSeed()); setMsg('Demo data loaded.'); }} />}
                <ConfirmButton label="Erase everything" confirmLabel="Tap again: erases all data" onConfirm={() => { replace(emptyDB()); setMsg('Everything cleared.'); }} />
            </div>
            {msg && <Caption>{msg}</Caption>}
        </Group>

        <Group label="Inspection & data help" heading>
            <Bullets items={[
                'It can photograph a device, record its serial, IMEI, BIS R-number and visible markings, and keep that evidence with the seller\'s track record.',
                'Barcode scanning appears on the Check tab only when this browser has a built-in reader; the app detects it and hides the button otherwise. A barcode can contain a serial, a web link or just a product code - never trust the format alone, read the value.',
                'It does not otherwise analyse photos: no text reading or image recognition runs here. The photo is for your own eyes and records, and this desk never prints "original" or "fake" from one.',
                'The maker\'s own serial or IMEI check and the BIS registration are strong supporting evidence, though even a valid serial is not proof that the physical device matches it. This desk links you straight to those official pages.',
                'Refurbished units: no app can see inside a device. The evidence is the wear checklist plus the seller\'s own record.',
                'Market prices are the prices you note yourself. There is no live price feed here.',
                'Stock, sales, deliveries and GST splits are computed from what you enter and stay in this browser only.',
            ]} />
        </Group>

        <Group label="Official verification pages">
            {BRAND_CHECKS.filter(b => b.brand !== 'Other').map(b => (
                <p className="link-line" key={b.brand}><TextLink href={b.url}>{b.label}</TextLink></p>
            ))}
            {BIS_CHECKS.map(b => (
                <p className="link-line" key={b.label}><TextLink href={b.url}>{b.label}</TextLink></p>
            ))}
            <Caption>Links verified 16 Nov 2026. Always type or navigate to these yourself rather than trusting a link a seller sends.</Caption>
        </Group>


    </>;
}
