import React, { useRef, useState } from 'react';
import { FileButton, Group } from '../ui';

const reference = { model: 'Circuit One', sampleId: 'DEMO-UNIT-001', battery: '500 mAh', finish: 'Graphite' };
const fields = [ ['model', 'Model'], ['sampleId', 'Demo unit ID'], ['battery', 'Case battery'], ['finish', 'Finish'] ] as const;
const labels = ['Model and demo ID match the sample label', 'Print and logo match the illustration', 'Case and accessories match the sample card'];
type Details = typeof reference;
const blank: Details = { model: '', sampleId: '', battery: '', finish: '' };
const normal = (value: string) => value.trim().replace(/\s+/g, ' ').toLowerCase();

export function SampleProduct() {
    const [details, setDetails] = useState<Details>({ ...blank });
    const [marks, setMarks] = useState([false, false, false]);
    const [result, setResult] = useState<null | { issues: string[] }>(null);
    const resultRef = useRef<HTMLDivElement>(null);
    function load(mismatch = false) {
        setDetails({ ...reference, ...(mismatch ? { sampleId: 'DEMO-UNIT-099' } : {}) });
        setMarks([true, true, true]);
        setResult(null);
    }
    function run() {
        const issues = fields.filter(([key]) => normal(details[key]) !== normal(reference[key])).map(([, label]) => label + ' does not match the sample card.');
        labels.forEach((label, i) => { if (!marks[i]) issues.push(label + ': not confirmed.'); });
        setResult({ issues });
        requestAnimationFrame(() => resultRef.current?.scrollIntoView({ block: 'center', behavior: 'auto' }));
    }
    return <>
        <div className="sample-intro"><p><a className="file-button secondary" href="#/check">Back to Check</a></p><span className="sample-pill">Demo</span><h2>A product.<br />A matching record.</h2></div>
        <div className="sample-layout">
            <section className="sample-card" aria-labelledby="sample-card-title">
                <svg className="sample-drawing" viewBox="0 0 360 245" role="img" aria-label="Illustration of fictional graphite earbuds and their case, not a product photograph">
                    <defs><linearGradient id="case-fill" x2="0.4" y2="1"><stop stopColor="#555c60"/><stop offset="1" stopColor="#20292c"/></linearGradient></defs>
                    <ellipse cx="180" cy="217" rx="116" ry="12" fill="#d1cebf"/>
                    <rect x="68" y="92" width="224" height="120" rx="48" fill="url(#case-fill)" stroke="#20292c" strokeWidth="3"/>
                    <path d="M71 145h218" stroke="#7d8789" strokeWidth="2"/>
                    <text x="180" y="176" textAnchor="middle" fill="#eeeade" fontSize="14" fontFamily="Arial" letterSpacing="3">CIRCUIT</text>
                    <circle cx="180" cy="190" r="3" fill="#b3d9aa"/>
                    <g fill="#354045" stroke="#172326" strokeWidth="2"><rect x="113" y="34" width="24" height="65" rx="12"/><ellipse cx="119" cy="37" rx="24" ry="18"/><rect x="222" y="34" width="24" height="65" rx="12"/><ellipse cx="240" cy="37" rx="24" ry="18"/></g>
                    <g fill="#849093"><ellipse cx="105" cy="37" rx="6" ry="10"/><ellipse cx="254" cy="37" rx="6" ry="10"/></g>
                </svg>
                <h3 id="sample-card-title">Circuit One</h3><p className="sample-kind">Wireless earbuds / exhibition concept</p>
                <dl className="sample-specs">{fields.map(([key, label]) => <div key={key}><dt>{label}</dt><dd>{reference[key]}</dd></div>)}<div><dt>Included</dt><dd>Earbuds, case, cable</dd></div></dl>
                <p className="sample-label">SAMPLE LABEL<br /><strong>CIRCUIT ONE · DEMO-UNIT-001</strong><br />500 mAh · Graphite · NOT FOR SALE</p>
            </section>
            <Group label="Compare the sample" heading>
                <div className="sample-actions"><FileButton onClick={() => load()}>Load matching sample</FileButton><FileButton variant="secondary" onClick={() => load(true)}>Try mismatched ID</FileButton></div>
                <div className="field-grid">{fields.map(([key, label]) => <label className="field" key={key}><span>{label}</span><input value={details[key]} onChange={event => { setDetails({ ...details, [key]: event.target.value }); setResult(null); }} placeholder={reference[key]} autoComplete="off" spellCheck={false}/></label>)}</div>
                <fieldset className="sample-checks"><legend>Visible sample checks</legend>{labels.map((label, index) => <label key={label}><input type="checkbox" checked={marks[index]} onChange={event => { setMarks(marks.map((value, i) => i === index ? event.target.checked : value)); setResult(null); }}/><span>{label}</span></label>)}</fieldset>
                <div className="sample-actions"><FileButton onClick={run}>Run sample comparison</FileButton><FileButton variant="secondary" onClick={() => { setDetails({ ...blank }); setMarks([false, false, false]); setResult(null); }}>Reset demo</FileButton></div>
            </Group>
        </div>
        {result && <div ref={resultRef} className={'sample-result ' + (result.issues.length ? 'sample-review' : 'sample-pass')} role="status" aria-live="polite">
            <h3>{result.issues.length ? 'Sample details need review' : 'Sample details match'}</h3>
            <p>{result.issues.length ? 'Review the details below.' : '4 details matched. 3 visible checks confirmed.'}</p>
            {!!result.issues.length && <ul>{result.issues.map(issue => <li key={issue}>{issue}</li>)}</ul>}
        </div>}
    </>;
}
