import React, { useEffect, useRef, useState } from 'react';
import { ButtonLink, Callout, Caption, ChoiceRow, FileButton, Group, Paragraph, Row, Rows } from '../ui';
import { DB, sellerBadge, StorageState } from '../lib/store';
import { BRAND_CHECKS, BIS_CHECKS, MARKING_CHECKLIST } from '../lib/brands';
import { timeStamp, uid } from '../lib/format';

type Photo = { url: string; name: string; sig: string };

type Props = {
    db: DB;
    saved: StorageState;
    update: (fn: (db: DB) => DB) => void;
};

const BRANDS = ['Apple', 'Samsung', 'Xiaomi', 'Dell', 'HP', 'Lenovo', 'Other'];
const CONDITIONS = ['New (sealed)', 'Refurbished (seller says so)', 'Used', 'Not sure'];

export function Check({ db, update }: Props) {
    const [photos, setPhotos] = useState<Photo[]>([]);
    const [attachmentOpen,setAttachmentOpen]=useState(false);
    const attachDialog=useRef<HTMLDialogElement|null>(null);
    const takeButton=useRef<HTMLDivElement|null>(null);
    useEffect(()=>{if(attachmentOpen)attachDialog.current?.showModal();else if(attachDialog.current?.open)attachDialog.current.close();},[attachmentOpen]);
    const [brand, setBrand] = useState('Apple');
    const [model, setModel] = useState('');
    const [serial, setSerial] = useState('');
    const [rNumber, setRNumber] = useState('');
    const [condition, setCondition] = useState(CONDITIONS[0]);
    const [sellerId, setSellerId] = useState('');
    const [price, setPrice] = useState('');
    const [marks, setMarks] = useState<boolean[]>(MARKING_CHECKLIST.map(() => false));
    const [ranAt, setRanAt] = useState<string | null>(null);
    const resultTop = useRef<HTMLDivElement | null>(null);
    useEffect(() => { setRanAt(null); setSavedNote(''); }, [marks, photos, brand, model, serial, rNumber, condition, sellerId, price]);
    useEffect(() => { if (ranAt) resultTop.current?.scrollIntoView({ block: 'start', behavior: 'auto' }); }, [ranAt]);
    const [step, setStep] = useState(0);
    const stepTop=useRef<HTMLDivElement|null>(null);
    useEffect(()=>{stepTop.current?.scrollIntoView({block:'start',behavior:'auto'});},[step]);
    const [demoDevice, setDemoDevice] = useState('A');
    const [demoRan, setDemoRan] = useState(false);
    const [savedNote, setSavedNote] = useState('');
    const [bcBusy, setBcBusy] = useState(false);
    const [bcResults, setBcResults] = useState<{ format: string; value: string }[] | null>(null);
    const [bcError, setBcError] = useState('');

    const barcodeSupported = typeof window !== 'undefined' && 'BarcodeDetector' in window;

    async function runBarcode() {
        setBcError('');
        setBcResults(null);
        setBcBusy(true);
        try {
            const bmp = await createImageBitmap(await (await fetch(photos[0].url)).blob());
            const det = new (window as unknown as { BarcodeDetector: new () => { detect: (src: ImageBitmap) => Promise<{ format: string; rawValue: string }[]> } }).BarcodeDetector();
            const found = await det.detect(bmp);
            if (!found.length) setBcError('No barcode found in this photo. Fill the frame with the code, keep it flat and sharp.');
            else setBcResults(found.map(f => ({ format: String(f.format).replace(/_/g, '-').toUpperCase(), value: String(f.rawValue) })));
        } catch (e) {
            setBcError('Barcode scanning failed in this browser. You can still type the serial by hand below.');
        }
        setBcBusy(false);
    }


    const cameraInput = useRef<HTMLInputElement | null>(null);
    const galleryInput = useRef<HTMLInputElement | null>(null);


    function addFiles(files: FileList | null) {
        if (!files) return;
        const next = Array.from(files).filter(f => f.type.startsWith('image/') && f.size > 0).map(f => ({ url: URL.createObjectURL(f), name: f.name, sig: f.name + ':' + f.size }));
        if (!next.length) return;
        setPhotos(prev => {
            const seen = new Set(prev.map(p => p.sig));
            const fresh = next.filter(p => {
                if (seen.has(p.sig)) return false;
                seen.add(p.sig);
                return true;
            });
            return fresh.length ? [...prev, ...fresh] : prev;
        });
    }

    const okCount = marks.filter(Boolean).length;
    const checklistState = okCount === MARKING_CHECKLIST.length ? 'pass' : okCount === 0 ? 'empty' : 'partial';
    const checklistTitle = checklistState === 'pass' ? 'All visible checks passed' : checklistState === 'empty' ? 'No visible checks confirmed' : 'Inspection incomplete';
    const seller = db.sellers.find(s => s.id === sellerId);
    const brandCheck = BRAND_CHECKS.find(b => b.brand === brand) || BRAND_CHECKS[BRAND_CHECKS.length - 1];

    function runCheck() {
        setRanAt(new Date().toISOString());
        setSavedNote('');
    }

    function saveRecord() {
        if (!ranAt) return;
        update(d => ({
            ...d,
            checks: [{
                id: uid(), at: ranAt, brand, model, serial, rNumber, condition,
                markingsOk: okCount, markingsTotal: MARKING_CHECKLIST.length,
                sellerName: seller ? seller.name : undefined, photoCount: photos.length,
            }, ...d.checks].slice(0, 20),
        }));
        setSavedNote('Saved to recent checks below. Photos themselves are not stored.');
    }

    const demoPanel = (
        <Group label="Scripted exhibition demo" heading>
            <Callout title="Demo only, not a real detection" tone="warning">
                This mode plays a scripted result for a two-device exhibition setup, so visitors can see how the
                final app will read. It does not analyse anything. Turn it off in Settings for real checks.
            </Callout>
            <ChoiceRow
                label="Device under the scanner"
                options={[{ value: 'A', label: 'Device A (scripted: original)' }, { value: 'B', label: 'Device B (scripted: fake)' }]}
                value={demoDevice}
                onChange={v => { setDemoDevice(v); setDemoRan(false); }}
            />
            <FileButton variant="primary" onClick={() => setDemoRan(true)}>Run the scripted scan</FileButton>
            {demoRan && (
                <div className={demoDevice === 'A' ? 'demo-verdict demo-ok' : 'demo-verdict demo-bad'}>
                    <p className="demo-tag">SCRIPTED DEMO RESULT</p>
                    <p className="demo-line">{demoDevice === 'A' ? 'Device A: looks original' : 'Device B: likely fake'}</p>
                    <p className="demo-sub">
                        {demoDevice === 'A'
                            ? 'In the planned product, the scanner gun would compare markings and serial against maker records. Here that result is pre-written.'
                            : 'In the planned product, mismatched markings or an unknown serial would raise this warning. Here that result is pre-written.'}
                    </p>
                </div>
            )}
        </Group>
    );

    return <>
        <dialog ref={attachDialog} className="attach-dialog" aria-labelledby="attach-title" onCancel={()=>setAttachmentOpen(false)} onClose={()=>{setAttachmentOpen(false);takeButton.current?.querySelector<HTMLButtonElement>('button')?.focus();}}>
          <div className="attachment-sign" aria-hidden="true"><svg viewBox="0 0 280 210" fill="none"><rect x="70" y="7" width="136" height="193" rx="3" fill="#ddd5bf" stroke="#6f6b5f" strokeWidth="3"/><path d="M78 14h120v178H78z" stroke="#f5eedb" strokeWidth="3"/><rect x="85" y="23" width="105" height="81" rx="2" fill="#292853" stroke="#8f8b9f" strokeWidth="3"/><rect x="92" y="30" width="91" height="67" fill="#3437a7"/><circle cx="138" cy="66" r="21" fill="#435be0" opacity=".8"/><circle cx="138" cy="66" r="9" fill="#8c9cec"/><path d="M105 111h63v14h-63z" fill="#b8af97" stroke="#8c826e"/><rect x="80" y="137" width="116" height="45" rx="3" fill="#272723"/><g className="mount-phone"><rect x="86" y="140" width="104" height="39" rx="6" fill="#131310" stroke="#77766c" strokeWidth="2"/><rect x="96" y="145" width="85" height="29" rx="2" fill="#f1efe3"/><path d="m128 159 7 6 13-14" stroke="#ed4d19" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></g><rect x="77" y="132" width="12" height="55" rx="3" fill="#171713"/><rect x="187" y="132" width="12" height="55" rx="3" fill="#171713"/><path className="attach-arrow" d="M246 159h-30m8-8-8 8 8 8" stroke="#ed4d19" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg><span>PHONE INTO BLACK HOLDER</span></div>
          <p className="eyebrow">Before the photo</p><h2 id="attach-title">Attach to gun.</h2><p>Place your phone in the black holder on the device. Tap Attached when ready to take a photo.</p><div className="attach-actions"><FileButton variant="secondary" onClick={()=>setAttachmentOpen(false)}>Not now</FileButton><FileButton variant="primary" onClick={()=>{setAttachmentOpen(false);cameraInput.current?.click();}}>Attached</FileButton></div><p className="mini-note">Manual confirmation. The desk does not detect the attachment.</p>
        </dialog>
        {db.demoMode ? demoPanel : (
            <>
                <div className="check-progress" ref={stepTop}><p><a className="file-button secondary" href="#/sample-product">Open sample product</a></p><p className="eyebrow">Device inspection</p><h2>One device.<br/>A clearer picture.</h2><div className="step-tabs">{['Capture','Identity','Inspect'].map((label,i)=><button key={label} aria-pressed={step===i} onClick={()=>setStep(i)}><span>{i+1}</span>{label}</button>)}</div><div className="progress-track"><i style={{width:((step+1)/3*100)+'%'}} /></div></div>
                <div hidden={step!==0} className="step-panel"><Group label="1. Photograph the device" heading>
                    <Paragraph>Capture the device, serial label and BIS mark. Photos stay in this session, with no upload. Barcode reading appears only if your browser supports it; review every value before copying.</Paragraph>
                    <input ref={cameraInput} type="file" accept="image/*" capture="environment" multiple className="vh"
                        onChange={e => { addFiles(e.target.files); e.target.value = ''; }} />
                    <input ref={galleryInput} type="file" accept="image/*" multiple className="vh"
                        onChange={e => { addFiles(e.target.files); e.target.value = ''; }} />
                    <div className="quick-actions" ref={takeButton}>
                        <FileButton variant="primary" onClick={() => setAttachmentOpen(true)}>Take photo</FileButton>
                        <FileButton variant="secondary" onClick={() => galleryInput.current && galleryInput.current.click()}>Upload from gallery</FileButton>
                    </div>
                    {photos.length > 0 && (
                        <>
                            <div className="photo-grid">
                                {photos.map((p, i) => (
                                    <div className="photo-cell" key={p.url}>
                                        <img src={p.url} alt={'Device photo ' + (i + 1)} />
                                        <button className="photo-remove" aria-label="Remove photo" onClick={() => setPhotos(prev => prev.filter(x => x.url !== p.url))}>×</button>
                                    </div>
                                ))}
                            </div>
                            <Caption>{photos.length} photo{photos.length === 1 ? '' : 's'} attached to this session. They are never uploaded and are not kept after you leave this page.</Caption>
                            <div className="quick-actions">
                                {barcodeSupported && (
                                    <FileButton variant="secondary" compact disabled={bcBusy} onClick={() => { void runBarcode(); }}>
                                        {bcBusy ? 'Scanning...' : 'Scan barcode in first photo'}
                                    </FileButton>
                                )}
                            </div>
                            {bcError && <Callout title="Barcode scan" tone="warning">{bcError}</Callout>}
                            {bcResults && bcResults.length > 0 && (
                                <div className="ocr-box">
                                    <p className="ocr-title">Barcodes found in the photo</p>
                                    {bcResults.map(b => {
                                        return (
                                            <div className="barcode-row" key={b.format + b.value}>
                                                <p className="barcode-value">{b.value}</p>
                                                <Caption>{b.format} - the format alone says nothing about what the value means: it can hold a serial, a URL, a product code or any text. Read it and decide yourself before copying it anywhere.</Caption>
                                                <div className="quick-actions">
                                                    <FileButton variant="secondary" compact onClick={() => setSerial(b.value)}>Copy value to serial field</FileButton>
                                                    {/^R-?\d{6,12}$/.test(b.value) && <FileButton variant="secondary" compact onClick={() => setRNumber(b.value.startsWith('R-') ? b.value : 'R-' + b.value.replace(/^R/, ''))}>Copy value to R-number field</FileButton>}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </>
                    )}
                </Group>

                <div className="step-controls"><FileButton onClick={()=>setStep(1)}>Next: device identity</FileButton></div></div>
                <div hidden={step!==1} className="step-panel"><Group label="2. Device identity" heading>
                    <ChoiceRow label="Brand" options={BRANDS.map(b => ({ value: b, label: b }))} value={brand} onChange={setBrand} />
                    <div className="field-grid">
                        <label className="field"><span>Model (as on the box)</span>
                            <input value={model} onChange={e => setModel(e.target.value)} placeholder="e.g. iPhone 13, Airdopes 131" inputMode="text" /></label>
                        <label className="field"><span>Serial number or IMEI</span>
                            <input value={serial} onChange={e => setSerial(e.target.value)} placeholder="Printed on the device" inputMode="text" autoCapitalize="characters" /></label>
                        <label className="field"><span>BIS R-number (if printed)</span>
                            <input value={rNumber} onChange={e => setRNumber(e.target.value)} placeholder="R- followed by digits" inputMode="text" /></label>
                        <label className="field"><span>Asking price (optional)</span>
                            <input value={price} onChange={e => setPrice(e.target.value.replace(/[^0-9.]/g, ''))} placeholder="₹" inputMode="decimal" /></label>
                    </div>
                    <ChoiceRow label="Condition the seller claims" options={CONDITIONS.map(c => ({ value: c, label: c }))} value={condition} onChange={setCondition} />
                    <label className="field"><span>Bought from</span>
                        <select value={sellerId} onChange={e => setSellerId(e.target.value)}>
                            <option value="">Not one of my listed sellers</option>
                            {db.sellers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                    </label>
                </Group>

                <div className="step-controls"><FileButton variant="secondary" onClick={()=>setStep(0)}>Back</FileButton><FileButton onClick={()=>setStep(2)}>Next: visible markings</FileButton></div></div>
                <div hidden={step!==2} className="step-panel"><Group label="3. Visible markings" heading>
                    <Paragraph>Tick only what you can see. These records support your inspection; they do not prove originality.</Paragraph>
                    <div className="inspection-count"><strong>{okCount}<small> / {MARKING_CHECKLIST.length}</small></strong><span>visible checks confirmed</span></div>
                    <div className="inspection-grid">
                        {MARKING_CHECKLIST.map((m,i)=><div key={m} className={'inspection-card '+(marks[i]?'is-checked':'')}><label><input type="checkbox" checked={marks[i]} onChange={e=>setMarks(prev=>prev.map((v,j)=>j===i?e.target.checked:v))} /><span>{['Logo & print','Model match','Unit serial','IMEI match','BIS mark','MRP label','Accessories','Wear & seals'][i]}</span></label><details><summary>What to look for</summary><p>{m}</p></details></div>)}
                    </div>
                    <FileButton variant="primary" onClick={runCheck}>Run the check</FileButton>
                </Group>

                </div>
                {ranAt && (
                    <Group label="Result: inspection outcome" heading>
                        <div ref={resultTop} className={'verdict-box verdict-' + checklistState} role="status" aria-live="polite" style={{ scrollMarginTop: 24 }}>
                            <p className="verdict-title">{checklistTitle}</p>
                            <p className="verdict-line">
                                {checklistState === 'pass'
                                    ? '8/8 passed in your manual inspection. No visible concerns were reported in this checklist.'
                                    : checklistState === 'empty'
                                    ? '0/8 confirmed. Inspect the device and tick only the checks you can confirm.'
                                    : `${okCount}/8 confirmed. ${8 - okCount} ${8 - okCount === 1 ? 'check remains' : 'checks remain'} unconfirmed. Review them before deciding.`}
                            </p>
                            <p className="verdict-line">
                                {okCount} of {MARKING_CHECKLIST.length} visible markings confirmed
                                {photos.length > 0 ? `, ${photos.length} photo${photos.length === 1 ? '' : 's'} attached` : ', no photos attached'}
                                {serial.trim() ? ', serial recorded' : ', no serial recorded'}.
                            </p>
                            <p className="verdict-note">
                                Checklist result only, not independent proof of authenticity. Unticked checks mean unconfirmed, not automatically fake.
                                This app does not analyse photos or verify the serial with the maker automatically.
                                {serial.trim() ? ' Use the official maker check below and match the returned model to the device.' : ' Record the device serial in Identity, then use the official maker check.'}
                                {' '}Use the BIS registration search where applicable. A copied valid serial can appear on a fake device, so match the physical device, box and official records before paying.
                                {condition !== CONDITIONS[0] ? ' For a used or refurbished unit, internal parts and repair history need a qualified inspection.' : ''}
                            </p>
                        </div>
                        {seller && (
                            <Callout title={'Seller record: ' + sellerBadge(seller).label} tone={sellerBadge(seller).label.startsWith('Meets shop rule') ? 'note' : 'warning'}>
                                {sellerBadge(seller).detail} This score comes from your own purchase records, the way Just Dial scores come from customer history. It is not an independent audit.
                            </Callout>
                        )}
                        <Rows>
                            {serial.trim() && <Row name={brandCheck.label} detail={brandCheck.hint} value="Official" valueKnown />}
                            <Row name={BIS_CHECKS[0].label} detail={BIS_CHECKS[0].hint} value="Official" valueKnown />
                            <Row name={BIS_CHECKS[1].label} detail={BIS_CHECKS[1].hint} value="Official" valueKnown />
                        </Rows>
                        <div className="quick-actions">
                            {serial.trim() && <ButtonLink href={brandCheck.url} variant="primary" compact>{brandCheck.label}</ButtonLink>}
                            <ButtonLink href={BIS_CHECKS[0].url} variant="secondary" compact>{BIS_CHECKS[0].label}</ButtonLink>
                            <ButtonLink href={BIS_CHECKS[1].url} variant="secondary" compact>{BIS_CHECKS[1].label}</ButtonLink>
                        </div>
                        {price.trim() && <Caption>Asking price noted: ₹{price}. Compare it with the market price you track on the Stock tab.</Caption>}
                        <div className="quick-actions">
                            <FileButton variant="secondary" compact onClick={saveRecord}>Save this check</FileButton>
                        </div>
                        {savedNote && <Caption>{savedNote}</Caption>}
                    </Group>
                )}
            </>
        )}

        {db.checks.length > 0 && (
            <Group label="Recent checks" heading>
                <Rows>
                    {db.checks.map(c => (
                        <Row key={c.id} name={(c.brand || 'Device') + (c.model ? ' ' + c.model : '')}
                            detail={`${timeStamp(c.at)} · ${c.markingsOk}/${c.markingsTotal} markings${c.serial ? ' · serial noted' : ''}${c.sellerName ? ' · ' + c.sellerName : ''}`}
                            value={c.condition === CONDITIONS[0] ? 'Claimed new' : c.condition} />
                    ))}
                </Rows>
                <Caption>Records keep the typed details only, never photos. Last {db.checks.length} checks.</Caption>
            </Group>
        )}
    </>;
}
