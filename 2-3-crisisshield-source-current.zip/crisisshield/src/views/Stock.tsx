import React, { useRef, useState } from 'react';
import { Callout, Caption, FileButton, Group, Paragraph } from '../ui';
import { DB, marketTrend, stockPace, StorageState } from '../lib/store';
import { ConfirmButton } from '../lib/Confirm';
import { guessMapping, parseSpreadsheet, xlsxSupported } from '../lib/xlsx';
import { inr, timeStamp, uid } from '../lib/format';

type Props = { db: DB; saved: StorageState; update: (fn: (db: DB) => DB) => void };

const FIELDS: { key: string; label: string; required?: boolean }[] = [
    { key: 'name', label: 'Product name', required: true },
    { key: 'sku', label: 'SKU or model code' },
    { key: 'qty', label: 'Quantity' },
    { key: 'cost', label: 'Cost price (per unit)' },
    { key: 'price', label: 'Selling price / MRP' },
    { key: 'gst', label: 'GST %' },
    { key: 'brand', label: 'Brand' },
    { key: 'seller', label: 'Dealer or seller' },
];

function toNum(v: string): number {
    const n = parseFloat(String(v).replace(/[^0-9.\-]/g, ''));
    return isNaN(n) ? 0 : n;
}

export function Stock({ db, update }: Props) {
    const fileInput = useRef<HTMLInputElement | null>(null);
    const [rows, setRows] = useState<string[][] | null>(null);
    const [map, setMap] = useState<Record<string, number>>({});
    const [sheetName, setSheetName] = useState('');
    const [importMsg, setImportMsg] = useState('');
    const [error, setError] = useState('');
    const [openId, setOpenId] = useState('');
    const [search,setSearch]=useState('');
    const [adding, setAdding] = useState(false);
    const blank = { name: '', sku: '', brand: '', cost: '', price: '', gst: String(db.gstDefault), stock: '', reorder: '5' };
    const [form, setForm] = useState(blank);
    const [marketPrice, setMarketPrice] = useState('');

    async function onFile(files: FileList | null) {
        setError(''); setImportMsg('');
        const f = files && files[0];
        if (!f) return;
        if (!xlsxSupported() && !f.name.toLowerCase().endsWith('.csv')) {
            setError('This browser cannot read .xlsx directly. Open the sheet in Excel or Google Sheets on the phone, download it as CSV, and upload that instead.');
            return;
        }
        try {
            const parsed = await parseSpreadsheet(f);
            if (parsed.length < 2) { setError('The sheet looks empty. The first row should be headers, the rows below it the items.'); return; }
            setSheetName(f.name);
            setRows(parsed);
            setMap(guessMapping(parsed[0]));
        } catch (e: any) {
            setError(e && e.message ? e.message : 'Could not read that file. Try saving it as CSV and uploading again.');
        }
    }

    function doImport() {
        if (!rows) return;
        if (map.name === undefined) { setError('Pick which column holds the product name.'); return; }
        const body = rows.slice(1);
        let added = 0, updated = 0, skipped = 0;
        update(d => {
            const products = [...d.products];
            const sellers = [...d.sellers];
            for (const r of body) {
                const name = String(r[map.name] || '').trim();
                if (!name) { skipped++; continue; }
                const sku = map.sku !== undefined ? String(r[map.sku] || '').trim() : '';
                const qty = map.qty !== undefined ? toNum(r[map.qty]) : 0;
                const cost = map.cost !== undefined ? toNum(r[map.cost]) : 0;
                const price = map.price !== undefined ? toNum(r[map.price]) : 0;
                const gst = map.gst !== undefined ? (toNum(r[map.gst]) || d.gstDefault) : d.gstDefault;
                const brand = map.brand !== undefined ? String(r[map.brand] || '').trim() : '';
                const sellerName = map.seller !== undefined ? String(r[map.seller] || '').trim() : '';
                let sellerId: string | undefined;
                if (sellerName) {
                    const found = sellers.find(s => s.name.toLowerCase() === sellerName.toLowerCase());
                    if (found) sellerId = found.id;
                    else {
                        const created = { id: uid(), name: sellerName, lots: 0, issues: 0, rating: 3 };
                        sellers.push(created);
                        sellerId = created.id;
                    }
                }
                const existing = sku ? products.find(p => p.sku.toLowerCase() === sku.toLowerCase()) : products.find(p => p.name.toLowerCase() === name.toLowerCase());
                if (existing) {
                    existing.stock += qty;
                    if (cost > 0) existing.cost = cost;
                    if (price > 0) existing.price = price;
                    if (brand) existing.brand = brand;
                    updated++;
                } else {
                    products.push({ id: uid(), name, sku, brand, cost, price, gst, stock: qty, reorder: 5, sellerId, createdAt: new Date().toISOString() });
                    added++;
                }
            }
            return { ...d, products, sellers };
        });
        setRows(null);
        setImportMsg(`Imported from ${sheetName}: ${added} new product${added === 1 ? '' : 's'}, ${updated} restocked${skipped ? `, ${skipped} empty row${skipped === 1 ? '' : 's'} skipped` : ''}.`);
    }

    function addProduct() {
        if (!form.name.trim()) return;
        update(d => ({
            ...d,
            products: [...d.products, {
                id: uid(), name: form.name.trim(), sku: form.sku.trim(), brand: form.brand.trim(),
                cost: toNum(form.cost), price: toNum(form.price), gst: toNum(form.gst) || d.gstDefault,
                stock: toNum(form.stock), reorder: toNum(form.reorder) || 5, createdAt: new Date().toISOString(),
            }],
        }));
        setForm(blank);
        setAdding(false);
    }

    function addMarketPrice(pid: string) {
        const v = toNum(marketPrice);
        if (v <= 0) return;
        update(d => ({
            ...d,
            market: { ...d.market, [pid]: [...(d.market[pid] || []), { at: new Date().toISOString(), price: v }].slice(-30) },
        }));
        setMarketPrice('');
    }

    function downloadSample() {
        const csv = 'Product name,SKU,Brand,Quantity,Cost price,MRP,GST%,Dealer\nboAt Airdopes 131,ADP-131,boAt,10,799,1299,18,Sharma Traders\nMi 20W charger,CHG-MI20,Xiaomi,20,349,599,18,Sharma Traders\n';
        const blob = new Blob([csv], { type: 'text/csv' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'sample-stock-sheet.csv';
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    }

    const header = rows ? rows[0] : [];
    const preview = rows ? rows.slice(1, 6) : [];

    return <>
        <Group label="Import a dealer sheet" heading>
            <Paragraph>Got a stock or order sheet from a dealer as Excel or CSV? Import it here. Existing SKUs get restocked, new ones are added. The sheet is read on this phone and never uploaded.</Paragraph>
            <input ref={fileInput} type="file" accept=".xlsx,.xlsm,.csv" className="vh" onChange={e => { void onFile(e.target.files); e.target.value = ''; }} />
            <div className="quick-actions">
                <FileButton variant="primary" onClick={() => fileInput.current && fileInput.current.click()}>Pick .xlsx or .csv</FileButton>
                <FileButton variant="secondary" compact onClick={downloadSample}>Sample sheet</FileButton>
                <FileButton variant="ghost" compact onClick={() => setAdding(a => !a)}>{adding ? 'Close form' : 'Add one product'}</FileButton>
            </div>
            {error && <Callout title="Could not import" tone="warning">{error}</Callout>}
            {importMsg && <Callout title="Import finished" tone="note">{importMsg}</Callout>}

            {rows && (
                <div className="import-box">
                    <p className="import-title">Match the columns of {sheetName}</p>
                    {FIELDS.map(f => (
                        <label className="field" key={f.key}>
                            <span>{f.label}{f.required ? ' (needed)' : ''}</span>
                            <select value={map[f.key] === undefined ? '' : String(map[f.key])}
                                onChange={e => setMap(m => { const n = { ...m }; if (e.target.value === '') delete n[f.key]; else n[f.key] = parseInt(e.target.value, 10); return n; })}>
                                <option value="">Not in this sheet</option>
                                {header.map((h, i) => <option key={i} value={i}>{String(h || 'Column ' + (i + 1))}</option>)}
                            </select>
                        </label>
                    ))}
                    <p className="import-title">First rows</p>
                    <div className="preview-scroll">
                        <table className="preview-table">
                            <thead><tr>{header.map((h, i) => <th key={i}>{String(h || '')}</th>)}</tr></thead>
                            <tbody>{preview.map((r, i) => <tr key={i}>{header.map((_, j) => <td key={j}>{String(r[j] || '')}</td>)}</tr>)}</tbody>
                        </table>
                    </div>
                    <div className="quick-actions">
                        <FileButton variant="primary" onClick={doImport}>Import {rows.length - 1} rows</FileButton>
                        <FileButton variant="ghost" compact onClick={() => setRows(null)}>Cancel</FileButton>
                    </div>
                </div>
            )}

            {adding && (
                <div className="import-box">
                    <p className="import-title">Add one product</p>
                    <div className="field-grid">
                        <label className="field"><span>Name</span><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
                        <label className="field"><span>SKU or model code</span><input value={form.sku} onChange={e => setForm({ ...form, sku: e.target.value })} /></label>
                        <label className="field"><span>Brand</span><input value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })} /></label>
                        <label className="field"><span>Cost price ₹</span><input inputMode="decimal" value={form.cost} onChange={e => setForm({ ...form, cost: e.target.value.replace(/[^0-9.]/g, '') })} /></label>
                        <label className="field"><span>Selling price ₹</span><input inputMode="decimal" value={form.price} onChange={e => setForm({ ...form, price: e.target.value.replace(/[^0-9.]/g, '') })} /></label>
                        <label className="field"><span>GST %</span><input inputMode="decimal" value={form.gst} onChange={e => setForm({ ...form, gst: e.target.value.replace(/[^0-9.]/g, '') })} /></label>
                        <label className="field"><span>Stock now</span><input inputMode="numeric" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value.replace(/[^0-9]/g, '') })} /></label>
                        <label className="field"><span>Reorder below</span><input inputMode="numeric" value={form.reorder} onChange={e => setForm({ ...form, reorder: e.target.value.replace(/[^0-9]/g, '') })} /></label>
                    </div>
                    <FileButton variant="primary" compact onClick={addProduct}>Save product</FileButton>
                </div>
            )}
        </Group>

        <Group label={`Products (${db.products.length})`} heading>
            {db.products.length === 0 && <Caption>No products yet. Import a sheet or add one above.</Caption>}
            <label className="field"><span>Find stock</span><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Product, brand or SKU" /></label>
            {db.products.filter(p=>(p.name+' '+p.sku+' '+p.brand).toLowerCase().includes(search.toLowerCase())).map(p => {
                const pace = stockPace(db, p);
                const trend = marketTrend(db.market[p.id]);
                const open = openId === p.id;
                return (
                    <div className="product-card" key={p.id}>
                        <button className="product-head" onClick={() => setOpenId(open ? '' : p.id)}>
                            <span className="product-name">{p.name}</span>
                            <span className="product-meta">{p.sku ? p.sku + ' · ' : ''}{p.brand || 'No brand'} · GST {p.gst}%</span>
                            <span className="product-nums">
                                <span className={p.stock <= p.reorder ? 'stock-low' : 'stock-ok'}>{p.stock} in stock</span>
                                <span>{inr(p.price)}</span>
                            </span>
                        </button>
                        {open && (
                            <div className="product-body">
                                <p className={`pace pace-${pace.tone}`}>{pace.label}{pace.daysCover !== null ? ` · about ${pace.daysCover} days of stock at the last 7 days' rate` : ''}</p>
                                <p className="product-meta">Cost {inr(p.cost)} · Margin {p.price > 0 ? Math.round(((p.price - p.cost) / p.price) * 100) : 0}% · Reorder below {p.reorder}</p>
                                <div className="field-grid">
                                    <label className="field"><span>Stock</span>
                                        <input inputMode="numeric" value={String(p.stock)} onChange={e => update(d => ({ ...d, products: d.products.map(x => x.id === p.id ? { ...x, stock: toNum(e.target.value) } : x) }))} /></label>
                                    <label className="field"><span>Selling price ₹</span>
                                        <input inputMode="decimal" value={String(p.price)} onChange={e => update(d => ({ ...d, products: d.products.map(x => x.id === p.id ? { ...x, price: toNum(e.target.value) } : x) }))} /></label>
                                    <label className="field"><span>Reorder below</span>
                                        <input inputMode="numeric" value={String(p.reorder)} onChange={e => update(d => ({ ...d, products: d.products.map(x => x.id === p.id ? { ...x, reorder: toNum(e.target.value) } : x) }))} /></label>
                                </div>
                                <p className="import-title">Market price you track</p>
                                {trend.last !== null && (
                                    <p className="product-meta">
                                        Last noted {inr(trend.last)}
                                        {trend.delta !== null && (
                                            <span className={trend.delta < -0.5 ? 'trend-down' : trend.delta > 0.5 ? 'trend-up' : ''}>
                                                {trend.delta > 0.5 ? ` ▲ ${Math.abs(trend.delta).toFixed(1)}% since last note` : trend.delta < -0.5 ? ` ▼ ${Math.abs(trend.delta).toFixed(1)}% since last note${p.price > trend.last ? ' · market is below your price, consider moving it fast' : ''}` : ' · flat since last note'}
                                            </span>
                                        )}
                                    </p>
                                )}
                                <div className="quick-actions">
                                    <label className="field field-inline"><span>Note today's market price ₹</span>
                                        <input inputMode="decimal" value={marketPrice} onChange={e => setMarketPrice(e.target.value.replace(/[^0-9.]/g, ''))} placeholder="What others sell it for" /></label>
                                    <FileButton variant="secondary" compact onClick={() => addMarketPrice(p.id)}>Save price</FileButton>
                                </div>
                                {(db.market[p.id] || []).length > 0 && (
                                    <Caption>Your notes: {(db.market[p.id] || []).slice(-5).map(pt => `${inr(pt.price)} on ${timeStamp(pt.at)}`).join(' · ')}. These are prices you enter yourself, not live market data.</Caption>
                                )}
                                <ConfirmButton label="Remove product" onConfirm={() => update(d => ({ ...d, products: d.products.filter(x => x.id !== p.id) }))} />
                            </div>
                        )}
                    </div>
                );
            })}
        </Group>
    </>;
}
