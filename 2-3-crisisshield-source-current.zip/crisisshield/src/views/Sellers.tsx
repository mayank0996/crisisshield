import React, { useState } from 'react';
import { Callout, Caption, FileButton, Group, Paragraph } from '../ui';
import { DB, sellerBadge } from '../lib/store';
import { ConfirmButton } from '../lib/Confirm';
import { uid } from '../lib/format';

type Props = { db: DB; update: (fn: (db: DB) => DB) => void };

export function Sellers({ db, update }: Props) {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [note, setNote] = useState('');

    function add() {
        if (!name.trim()) return;
        update(d => ({
            ...d,
            sellers: [...d.sellers, { id: uid(), name: name.trim(), phone: phone.trim() || undefined, lots: 0, issues: 0, rating: 3, note: note.trim() || undefined }],
        }));
        setName(''); setPhone(''); setNote('');
    }

    function bump(id: string, field: 'lots' | 'issues', by: number) {
        update(d => ({
            ...d,
            sellers: d.sellers.map(s => s.id === id ? { ...s, [field]: Math.max(0, s[field] + by) } : s),
        }));
    }

    function setRating(id: string, rating: number) {
        update(d => ({ ...d, sellers: d.sellers.map(s => s.id === id ? { ...s, rating } : s) }));
    }

    return <>
        <Group label="Your seller records" heading>
            <Paragraph>Your buying history, not a third-party certificate. "Meets shop rule" requires 10+ lots, under 5% problem lots and your rating of 4 or above.</Paragraph>
            {db.sellers.length === 0 && <Caption>No sellers yet. Add your first dealer below, or import a sheet that names dealers.</Caption>}
            {db.sellers.map(s => {
                const badge = sellerBadge(s);
                const certified = badge.label.startsWith('Meets shop rule');
                return (
                    <div className="seller-card" key={s.id}>
                        <p className="seller-name">{s.name}{s.phone ? ` · ${s.phone}` : ''}</p>
                        <p className={certified ? 'badge badge-yes' : 'badge'}>{badge.label}</p>
                        <p className="seller-detail">{badge.detail}</p>
                        {s.note && <p className="seller-detail">Note: {s.note}</p>}
                        <div className="quick-actions">
                            <FileButton variant="secondary" compact onClick={() => bump(s.id, 'lots', 1)}>Lot received ({s.lots})</FileButton>
                            <FileButton variant="secondary" compact onClick={() => bump(s.id, 'issues', 1)}>Problem lot ({s.issues})</FileButton>
                        </div>
                        <div className="rating-row" role="group" aria-label="Your rating">
                            {[1, 2, 3, 4, 5].map(r => (
                                <button key={r} className={'rating-dot' + (s.rating >= r ? ' on' : '')} onClick={() => setRating(s.id, r)} aria-label={`Rate ${r} out of 5`}>{r}</button>
                            ))}
                        </div>
                        <ConfirmButton label="Remove seller" onConfirm={() => update(d => ({ ...d, sellers: d.sellers.filter(x => x.id !== s.id) }))} />
                    </div>
                );
            })}
        </Group>
        <Group label="Add a seller" heading>
            <div className="field-grid">
                <label className="field"><span>Name</span><input value={name} onChange={e => setName(e.target.value)} placeholder="Dealer or shop name" /></label>
                <label className="field"><span>Phone (optional)</span><input inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} /></label>
            </div>
            <label className="field"><span>Note (optional)</span><input value={note} onChange={e => setNote(e.target.value)} placeholder="e.g. always gives GST bill" /></label>
            <FileButton variant="primary" compact onClick={add}>Save seller</FileButton>
            <Callout title="Honest limit" tone="note">
                A seller record lowers the chance of a fake, it never removes it. Repeat offenders fake reputations too, so
                keep running the serial and BIS checks on the Check tab for anything expensive.
            </Callout>
        </Group>
    </>;
}
